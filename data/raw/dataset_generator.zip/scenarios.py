"""Ticket scenarios for the synthetic vector-DB dataset (6 categories x 5 subcategories).

Each scenario = one recurring incident pattern. The generator combines its titles, symptom
sentences, error codes, apps and resolutions with shared context pools (onset, tried steps,
impact, urgency, location) to produce varied, realistic tickets.

Placeholders: {code} error code/message, {app} application/device/resource, {loc} office
location, {ap} access-point id, {dept} department.
Resolution strings are prefixed with the resolving tier: "L1|", "L2|" or "L3|".
"""
from dataclasses import dataclass, field


@dataclass
class Scenario:
    sid: str
    category: str
    subcategory: str
    kb: str | None
    titles: list[str]
    symptoms: list[str]
    codes: list[str] = field(default_factory=list)
    resolutions: list[str] = field(default_factory=list)
    apps: list[str] = field(default_factory=list)
    envs: list[str] = field(default_factory=lambda: ["office", "remote"])
    min_priority: str | None = None
    intent: str = "incident"          # incident | request | how_to
    impact_bias: float = 1.0          # >1 makes multi-user impact more likely
    weight: float = 1.0


SCENARIOS: list[Scenario] = []


def S(*args, **kw):
    SCENARIOS.append(Scenario(*args, **kw))


N, D, H, SW, AS, IH = "Network", "Database", "Hardware", "Software", "Access & Security", "Inquiry/Help"

# =============================================================================== NETWORK
S("VPN.gateway", N, "VPN", "KB-0018",
  ["Cannot connect to VPN from home", "VPN fails with '{code}'", "VPN client stuck on connecting",
   "Unable to establish VPN connection", "VPN not connecting"],
  ["The {app} keeps failing to connect and shows '{code}'.",
   "My internet works fine but the {app} will not connect to the corporate gateway.",
   "Every time I try to connect to the VPN it spins for about 30 seconds and then fails.",
   "The VPN goes back to disconnected right after I enter my credentials and approve MFA."],
  ["Gateway not responding", "VPN connection failed", "IKEv2 error"],
  ["L1|Confirmed internet access, enabled automatic date/time and reinstalled the approved {app} from the company portal. VPN connected and intranet reachable.",
   "L1|User had an outdated gateway profile. Re-imported the published profile and connected once. Access to internal systems verified.",
   "L2|Gateway node VPN-GW-02 was not responding. NET-OPS failed over to the secondary gateway; user reconnected and confirmed access.",
   "L1|Client diagnostic showed home router blocking IPsec. User switched to the SSL fallback profile as documented; connection stable."],
  apps=["GlobalProtect VPN client", "Cisco AnyConnect client", "FortiClient VPN"], envs=["remote"])

S("VPN.drops", N, "VPN", "KB-0018",
  ["VPN keeps disconnecting", "VPN drops every few minutes", "Remote desktop sessions lost due to VPN drops",
   "Unstable VPN connection"],
  ["My VPN disconnects every 10-15 minutes and I have to reconnect manually.",
   "The VPN connects but drops whenever I start a large file transfer.",
   "I lose my remote desktop session several times an hour because the VPN drops.",
   "The {app} disconnects with '{code}' and I lose unsaved work on the remote server."],
  ["VPN connection failed", "Connection lost", "Gateway not responding"],
  ["L1|Home Wi-Fi was unstable. User moved to a wired connection and updated the VPN client; no drops over two days of monitoring.",
   "L2|Client diagnostic bundle showed dead-peer-detection timeouts. NET-OPS adjusted the keepalive interval on the gateway profile; drops stopped.",
   "L1|Wi-Fi adapter power saving was turning off the adapter. Disabled adapter power management as per support guide and reconnected.",
   "L2|Gateway was overloaded during peak hours. NET-OPS moved the user group to a less loaded gateway pool."],
  apps=["GlobalProtect VPN client", "Cisco AnyConnect client", "FortiClient VPN"], envs=["remote"])

S("VPN.slow", N, "VPN", "KB-0019",
  ["VPN very slow", "Internal apps slow over VPN", "File transfers crawl when connected to VPN",
   "Slow performance on VPN"],
  ["Everything is extremely slow once I connect to the VPN, pages take ages to load.",
   "Only {app} is slow over VPN, other internal sites are fine.",
   "Copying files from the file server over VPN runs at a fraction of the normal speed.",
   "Video calls freeze when I am connected to the VPN, latency shows '{code}'."],
  ["High VPN latency", "Packet loss", "Throughput below baseline"],
  ["L1|A personal cloud backup was saturating the home connection. Paused it and restarted the VPN client; speed back to normal.",
   "L2|Gateway utilisation was above 90% at peak. NET-OPS moved the user to the nearest regional gateway; latency reduced from 180 ms to 40 ms.",
   "L2|Traffic for {app} was routed via a remote data centre. NET-OPS corrected the route through a change request.",
   "L1|Client version was two releases old. Installed the approved version from the company portal; throughput normal."],
  apps=["SAP GUI", "the file server", "the intranet portal", "Jira"], envs=["remote"])

S("VPN.auth", N, "VPN", "KB-0018",
  ["VPN authentication failing", "VPN rejects my login", "Cannot authenticate to VPN"],
  ["The VPN rejects my credentials with '{code}' even though I can log in to email.",
   "Since changing my password yesterday the VPN keeps saying authentication failed.",
   "The VPN client warns that my device certificate is not valid and refuses to connect."],
  ["Authentication failed", "Certificate expired"],
  ["L1|Old password cached in the VPN client. Cleared saved credentials and signed in with the new password and MFA; connected.",
   "L1|Device certificate had expired. Renewed it through the Company Portal compliance check; VPN connected.",
   "L2|User was missing from the VPN access group after a role change. IAM re-added the user to the approved group."],
  apps=["GlobalProtect VPN client", "Cisco AnyConnect client"], envs=["remote"])

S("WIFI.area_drops", N, "Wireless", "KB-0021",
  ["WiFi drops in meeting rooms", "Wireless disconnects on {loc}", "Unstable WiFi in conference room",
   "Laptop loses WiFi when moving between floors", "WiFi keeps dropping during calls"],
  ["My laptop keeps losing WiFi in the meeting rooms on {loc}.",
   "WiFi disconnects every few minutes near the east side of {loc}, but it is fine at my desk.",
   "Signal shows 2-3 bars and then suddenly drops during video calls on {loc}.",
   "The connection drops every 5-10 minutes in the conference rooms and the log shows '{code}'."],
  ["WLAN AutoConfig disconnected", "Limited connectivity", "High packet loss"],
  ["L2|NET-OPS found access point AP-{ap} overloaded and on a congested channel. Rebalanced channels and added capacity; retest stable.",
   "L2|Faulty access point AP-{ap} in the meeting room was replaced by NET-OPS. Connectivity stable in follow-up test.",
   "L1|Outdated wireless driver. Installed the approved driver from the company portal; roaming between APs became stable.",
   "L2|Roaming threshold misconfigured after controller upgrade. NET-OPS corrected the RF profile for the floor."],
  envs=["office"], impact_bias=1.6)

S("WIFI.auth", N, "Wireless", "KB-0020",
  ["Cannot connect to corporate WiFi", "WiFi keeps asking for credentials", "Corporate SSID authentication failing",
   "Laptop won't join office WiFi"],
  ["I can see the corporate WiFi but it won't connect, it says '{code}'.",
   "The corporate network keeps prompting for my credentials and then fails, but guest WiFi works.",
   "After my laptop was reimaged it no longer joins the corporate SSID."],
  ["Can't connect to this network", "802.1X authentication failed", "Certificate expired"],
  ["L1|Device certificate missing after reimage. Re-enrolled through Company Portal and reconnected to the corporate SSID.",
   "L1|System clock was wrong, causing certificate validation failure. Enabled automatic time sync; authentication succeeded.",
   "L2|RADIUS logs showed the account was not in the wireless access group. IAM corrected the group membership."],
  envs=["office"])

S("WIFI.no_internet", N, "Wireless", "KB-0041",
  ["Connected to WiFi but no internet", "WiFi shows connected, no network access", "No internet on office WiFi"],
  ["WiFi says connected but nothing loads, the icon shows '{code}'.",
   "I'm connected to the office WiFi but cannot reach any website or internal app.",
   "My laptop joins the WiFi on {loc} but gets no internet."],
  ["No internet, secured", "Limited connectivity"],
  ["L1|Adapter had a stale lease. Ran ipconfig /release and /renew and reconnected; internet restored.",
   "L2|DHCP scope for the wireless VLAN was exhausted. NET-OPS shortened the lease time and expanded the scope.",
   "L1|A manual proxy left by a troubleshooting tool blocked traffic. Restored automatic proxy settings."],
  envs=["office"], impact_bias=1.4)

S("WIFI.slow", N, "Wireless", "KB-0021",
  ["Slow WiFi in office", "WiFi speed very low", "Video calls freeze on WiFi"],
  ["WiFi is connected but extremely slow on {loc}, video calls freeze.",
   "Downloads over WiFi are much slower than usual and pages time out.",
   "Speed tests on the office WiFi show very low bandwidth since this week."],
  ["High packet loss", "Limited connectivity"],
  ["L2|Channel interference from a neighbouring network. NET-OPS changed the AP channel plan on the floor.",
   "L1|Laptop was connecting on the 2.4 GHz band. Set preferred band to 5 GHz as per support guide; speed normal.",
   "L2|Access point AP-{ap} uplink negotiated at 100 Mbps. NET-OPS replaced the patch cable."],
  envs=["office"], impact_bias=1.3)

S("DNS.internal_name", N, "DNS/DHCP", "KB-0023",
  ["Cannot open internal site by name", "Intranet not resolving", "Server name not found",
   "Internal hostname does not resolve"],
  ["I can't open {app} by its name, the browser shows '{code}'.",
   "The internal server works by IP address but not by hostname.",
   "Since this morning internal links fail with a server not found error.",
   "nslookup for {app} returns '{code}'."],
  ["DNS_PROBE_FINISHED_NXDOMAIN", "Name or service not known", "DNS server not responding"],
  ["L1|User was not on VPN while accessing an internal hostname. Connected to VPN and flushed DNS cache; site opened.",
   "L2|DNS record for the server was removed during migration. NET-OPS recreated the A record.",
   "L1|Public DNS was manually configured on the adapter. Restored automatic DNS settings and flushed cache."],
  apps=["the intranet portal", "the HR portal", "the build server", "the reporting site", "the wiki"])

S("DHCP.apipa", N, "DNS/DHCP", "KB-0041",
  ["No network - 169.254 address", "Laptop not getting IP address", "Ethernet shows unidentified network",
   "Desk network port not working"],
  ["My laptop gets a 169.254.x.x address on the wired network and has no connectivity.",
   "Ethernet says '{code}' and nothing works.",
   "Several desks on {loc} cannot get a network address after the weekend.",
   "The docking station network connection shows '{code}' every morning."],
  ["No valid IP configuration", "Unidentified network", "Limited connectivity"],
  ["L1|Released and renewed the IP lease; device received a valid address.",
   "L2|DHCP relay on the floor switch was misconfigured after maintenance. NET-OPS corrected the helper address.",
   "L2|DHCP scope exhausted. NET-OPS cleared stale leases and extended the scope.",
   "L2|Wall port was patched to an unused VLAN. NET-OPS re-patched the port."],
  envs=["office"], impact_bias=1.5)

S("DHCP.conflict", N, "DNS/DHCP", "KB-0041",
  ["IP address conflict warning", "Network keeps dropping - IP conflict", "Duplicate IP address on network"],
  ["Windows warns '{code}' and my network connection keeps dropping.",
   "I keep losing network with an IP conflict message every morning.",
   "Two devices on {loc} keep knocking each other off the network."],
  ["Windows has detected an IP address conflict"],
  ["L2|A printer had a static IP inside the DHCP range. NET-OPS added a reservation and moved the printer outside the dynamic range.",
   "L1|Renewed the lease after NET-OPS identified and removed the conflicting device."],
  envs=["office"])

S("DNS.stale", N, "DNS/DHCP", "KB-0023",
  ["Website resolves to wrong server", "Old server still being reached after migration", "DNS lookups slow"],
  ["{app} still opens the old server even though it was migrated last week.",
   "Name lookups take a long time and some internal sites resolve to the wrong address.",
   "Some users reach the new {app} and others the old one, lookups show '{code}'."],
  ["SERVFAIL", "DNS server not responding"],
  ["L1|Stale DNS cache. Ran ipconfig /flushdns and the new address resolved.",
   "L2|TTL on the old record was very high and a stale record remained on one resolver. NET-OPS cleared it."],
  apps=["the reporting site", "the CRM portal", "the file server"])

S("FW.app_blocked", N, "Firewall", "KB-0022",
  ["Application cannot reach server - connection timed out", "Firewall blocking {app}",
   "Port blocked after network change", "Integration endpoint unreachable"],
  ["{app} stopped connecting to its server after last week's network change, it shows '{code}'.",
   "The application works from home but times out inside the office.",
   "Our integration can't reach the partner API endpoint on port 443 anymore.",
   "{app} fails with '{code}' only from the new subnet."],
  ["Connection timed out", "Connection refused", "Firewall deny/drop log"],
  ["L2|Firewall logs showed denies from the new subnet. Change request raised and a narrow rule added after security approval.",
   "L2|Destination IP changed at the vendor. Firewall object updated through change control.",
   "L1|Issue was the application proxy setting, not the firewall. Applied the documented proxy configuration."],
  apps=["the payroll client", "the SFTP transfer job", "the partner API integration", "the license server client"],
  impact_bias=1.4)

S("FW.web_filter", N, "Firewall", "KB-0042",
  ["Website blocked by web filter", "Business website blocked", "Need site unblocked",
   "Company filter blocking {app}"],
  ["I need {app} for work but it shows '{code}'.",
   "A supplier portal I use daily is now blocked by the company filter.",
   "The training site we were told to use is categorised as blocked."],
  ["Access denied by web filter", "This site has been blocked by your organization"],
  ["L2|Security reviewed the URL and recategorised it as business. Access confirmed.",
   "L1|Site had already been recategorised. Cleared browser cache; block page no longer shown.",
   "L2|Unblock request rejected by security because of malware risk. An approved alternative source was provided."],
  apps=["a supplier portal", "an industry research site", "a training website", "the government tax portal"])

S("FW.proxy", N, "Firewall", "KB-0042",
  ["Browser shows proxy connection failed", "No websites load - proxy error", "Internet not working in any browser"],
  ["Every website fails with '{code}' on my laptop.",
   "Internet stopped working in all browsers with a proxy error.",
   "Internal sites load but external websites show '{code}'."],
  ["ERR_PROXY_CONNECTION_FAILED", "ERR_TUNNEL_CONNECTION_FAILED"],
  ["L1|A manual proxy setting was left by a tool. Restored managed proxy configuration; browsing works.",
   "L2|Proxy node outage. NET-OPS restored the service and users reconnected."],
  impact_bias=1.3)

S("NDRV.not_mapped", N, "Network Drive", "KB-0024",
  ["Shared drive missing", "Network drive not mapping at login", "'{code}' when opening mapped drive",
   "Mapped drive disappeared"],
  ["My mapped drive is missing after I sign in.",
   "The shared drive letter disappeared and opening it shows '{code}'.",
   "The network drive only appears after I reconnect the VPN.",
   "My Z: drive shows a red X and says '{code}'."],
  ["System error 67", "The network name cannot be found", "The specified network path was not found"],
  ["L1|Device signed in before VPN connected. Reconnected VPN and reran the mapping; drive appears.",
   "L1|Remapped the drive with the approved UNC path and 'Reconnect at sign-in'.",
   "L2|File server alias changed during migration. Group Policy drive mapping updated."])

S("NDRV.access", N, "Network Drive", "KB-0025",
  ["Network share access problem", "Access denied on shared folder", "Permission issue on team drive"],
  ["I can see the {app} folder but get '{code}' when I open it.",
   "I can open files on the team share but cannot save changes.",
   "A new colleague cannot access the department share that the rest of us use."],
  ["Access is denied", "You do not have permission to access"],
  ["L2|User was not in the share security group. Owner approved and IAM added the user.",
   "L1|User was signed in with an old token after a group change. Signed out and back in; access works."],
  apps=["Finance", "Projects", "HR", "Sales", "Marketing"])

S("NDRV.slow", N, "Network Drive", None,
  ["Network drive very slow", "Opening files from shared drive takes minutes", "File Explorer freezes on network drive"],
  ["Files on the shared drive take minutes to open.",
   "Browsing the network drive freezes File Explorer.",
   "Saving Excel files to the team share takes forever since Monday."],
  [],
  ["L2|File server disk queue was saturated by a backup job running in business hours. Storage team moved the schedule.",
   "L2|SMB signing mismatch on older clients caused slowness. Endpoint team applied the updated policy."],
  impact_bias=1.5)

# =============================================================================== DATABASE
S("ORA.slow", D, "Oracle", "KB-0001",
  ["Oracle report very slow", "Queries timing out in Oracle", "Month-end report taking 10+ minutes",
   "Oracle query performance degraded"],
  ["The {app} report on Oracle now takes over 10 minutes, it used to take seconds.",
   "Queries against the orders table time out with '{code}'.",
   "One particular Oracle report is consistently slow while others are fine.",
   "The application log shows '{code}' whenever we run the monthly summary."],
  ["ORA-01013", "SQL query timeout"],
  ["L2|Execution plan showed a full table scan after statistics went stale. DBA refreshed statistics and the plan returned to index access.",
   "L2|Missing index on ORDER_DATE identified. DBA added the index through a change in the evening window; report runs in 25 seconds.",
   "L3|Plan regression after patching. DBA fixed the previous plan with a SQL plan baseline."],
  apps=["sales reporting", "finance reporting", "inventory reporting"], impact_bias=1.6)

S("ORA.tns", D, "Oracle", "KB-0031",
  ["'{code}' cannot connect to Oracle", "Oracle connection fails with TNS error",
   "Application cannot reach Oracle database", "SQL Developer connection error"],
  ["SQL Developer fails with '{code}' when I connect to the {app} database.",
   "The application cannot connect to Oracle and the log shows '{code}'.",
   "Since the server move nobody on the team can connect to the Oracle database."],
  ["ORA-12154", "ORA-12541", "ORA-12514"],
  ["L1|User's TNS_ADMIN pointed to an old tnsnames.ora. Corrected it to the managed location; connection works.",
   "L2|Listener on the DB host was down after a reboot. DBA started the listener and verified service registration.",
   "L2|Service name changed after migration. Application connection string updated through change."],
  apps=["CRM", "billing", "HR", "warehouse"], impact_bias=1.3)

S("ORA.tablespace", D, "Oracle", "KB-0032",
  ["Oracle error '{code}' on insert", "Batch job failing - tablespace full", "Inserts failing in Oracle"],
  ["The nightly load failed with '{code}'.",
   "Users can't save new records, the application shows '{code}'.",
   "Our ETL job keeps failing on insert into the {app} schema."],
  ["ORA-01653", "ORA-01654", "ORA-01652"],
  ["L2|DBA added a datafile to the tablespace via emergency change; job rerun successfully.",
   "L2|Temp tablespace exhausted by a runaway sort. Query tuned and temp tablespace resized.",
   "L3|Storage array nearly full. Storage team expanded the LUN and DBA extended the tablespace."],
  apps=["DWH", "orders", "claims"], min_priority="P2", impact_bias=1.5)

S("ORA.access", D, "Oracle", "KB-0003",
  ["Oracle login problem: '{code}'", "Cannot log in to Oracle schema", "Oracle account issue"],
  ["My Oracle login fails with '{code}'.",
   "The scheduled job stopped connecting to Oracle overnight with '{code}'.",
   "I am told my Oracle password has expired."],
  ["ORA-28000", "ORA-28001", "ORA-01017"],
  ["L1|Account unlocked by DBA after identity verification; user reset password through the identity portal.",
   "L2|Service account password rotated without updating the job. Owner updated the secret in the vault and the job config."])

S("MSS.login", D, "MS SQL Server", "KB-0003",
  ["SQL Server login failed 18456", "Cannot access SQL database", "SQL Server access denied for user",
   "Login failed for user on SQL Server"],
  ["Connecting to the {app} database gives '{code}'.",
   "A new team member cannot access the database but others in the same role can.",
   "SSMS shows login failed for my user since this morning."],
  ["SQL Server error 18456", "Login failed for user"],
  ["L2|User missing from the database role group. Owner approved and DBA added the minimum role.",
   "L1|User was connecting with SQL authentication instead of Windows authentication. Corrected connection settings.",
   "L2|Default database for the login had been dropped. DBA updated the default database."],
  apps=["customer", "reporting", "inventory"])

S("MSS.log_full", D, "MS SQL Server", "KB-0033",
  ["Transaction log full error 9002", "SQL database stopped accepting writes", "Log file full on SQL Server"],
  ["The app throws '{code}' and no transactions are saved.",
   "Writes to the {app} database are failing, the DBA alert shows the log at 100%.",
   "Our nightly import failed because the transaction log is full."],
  ["Error 9002", "The transaction log for database is full due to 'LOG_BACKUP'"],
  ["L2|Log backup job had been failing for 3 days. DBA fixed the backup destination and ran a log backup; log space reused.",
   "L2|A long-running open transaction from a stuck report held the log. Owner approved ending the session; log truncated.",
   "L3|Log drive full. Storage expanded and log backup frequency increased."],
  apps=["orders", "payments", "CRM"], min_priority="P2", impact_bias=1.5)

S("MSS.deadlock", D, "MS SQL Server", "KB-0034",
  ["Deadlock errors in application", "Transaction chosen as deadlock victim", "Orders failing intermittently with 1205"],
  ["Users intermittently get '{code}' when saving orders.",
   "The batch job and the app keep deadlocking each other during the day.",
   "We see lock timeout errors on the {app} database during peak hours."],
  ["Error 1205", "Lock request time out period exceeded"],
  ["L2|Deadlock graph showed conflicting update order. Developers changed the order and added retry logic.",
   "L2|Added a covering index to remove the scan causing lock escalation; deadlocks stopped."],
  apps=["orders", "booking", "inventory"], impact_bias=1.4)

S("MSS.slow", D, "MS SQL Server", "KB-0001",
  ["SQL Server query slow", "Dashboard timing out on SQL Server", "Reports slow after data load"],
  ["The {app} dashboard times out with '{code}'.",
   "Queries on SQL Server got much slower after last week's data load.",
   "A stored procedure that took seconds now runs for several minutes."],
  ["SQL Server query timeout", "Execution Timeout Expired"],
  ["L2|Query Store showed a plan regression. DBA forced the last good plan.",
   "L2|Statistics outdated after bulk load. DBA updated statistics; dashboard loads in seconds."],
  apps=["sales", "operations", "finance"], impact_bias=1.4)

S("DB2.comm", D, "DB2", "KB-0035",
  ["DB2 '{code}' communication error", "Cannot connect to DB2", "DB2 connection drops"],
  ["The {app} job fails with '{code}' when connecting to DB2.",
   "Connections to DB2 drop after being idle for a while.",
   "Nobody can connect to the DB2 database since the maintenance window."],
  ["SQL30081N", "SQL1224N", "SQL1032N"],
  ["L2|Firewall idle timeout was closing sessions. NET-OPS raised the timeout and the application enabled keepalive.",
   "L2|DB2 instance was not started after maintenance. DBA started the instance through change.",
   "L1|Node catalog had the old hostname. Recatalogued with the documented values."],
  apps=["mainframe batch", "claims processing", "core banking report"], impact_bias=1.4)

S("DB2.deadlock", D, "DB2", "KB-0036",
  ["DB2 '{code}' error", "DB2 lock contention", "Transactions rolled back in DB2"],
  ["Our application gets '{code}' and the transaction rolls back.",
   "Batch updates conflict with online users and fail with a lock timeout.",
   "The {app} update fails intermittently with '{code}'."],
  ["SQL0911N reason code 2", "SQL0911N reason code 68"],
  ["L2|Long unit of work in the batch. App team increased commit frequency.",
   "L2|RUNSTATS were stale causing table scans. DBA ran RUNSTATS and lock waits dropped."],
  apps=["claims processing", "policy admin", "billing"], impact_bias=1.3)

S("DB2.slow", D, "DB2", "KB-0001",
  ["DB2 query slow", "DB2 report running long", "DB2 performance degraded"],
  ["The {app} report on DB2 runs for over an hour.",
   "Queries on DB2 have slowed down since the last data load.",
   "The DB2 batch window overran this morning."],
  [],
  ["L2|REORG and RUNSTATS on the large table restored performance.",
   "L2|Added an index recommended by db2advis after DBA review."],
  apps=["claims", "core banking", "policy"], impact_bias=1.3)

S("DB2.auth", D, "DB2", "KB-0003",
  ["DB2 authentication failed", "'{code}' security processing failed", "Cannot log in to DB2"],
  ["DB2 rejects my login with '{code}'.",
   "The service account for the job can no longer authenticate to DB2."],
  ["SQL30082N"],
  ["L1|Password expired. User reset it through the identity portal.",
   "L2|Service account password rotated. Owner updated the vault and the job."])

S("PG.auth", D, "PostgreSQL", "KB-0037",
  ["PostgreSQL authentication error", "Postgres login rejected", "Cannot connect to Postgres - access rejected"],
  ["psql fails with '{code}'.",
   "Our new app server cannot connect to PostgreSQL, the error mentions pg_hba.conf.",
   "The {app} lost access to the Postgres database after credential rotation."],
  ["FATAL: password authentication failed for user", "FATAL: no pg_hba.conf entry for host"],
  ["L2|DBA added a narrow pg_hba.conf entry for the new subnet with scram-sha-256 and reloaded the configuration.",
   "L2|Secret in the vault updated after rotation and the service restarted by the owner.",
   "L1|User was connecting to the wrong database name. Corrected the connection string."],
  apps=["analytics service", "order service", "ticketing service"])

S("PG.too_many", D, "PostgreSQL", "KB-0038",
  ["Postgres too many clients", "Application errors - connection slots exhausted", "Database refusing new connections"],
  ["The {app} is failing with '{code}'.",
   "Users get intermittent errors and the database refuses new connections.",
   "After today's release the API returns errors and the DB log says '{code}'."],
  ["FATAL: sorry, too many clients already", "FATAL: remaining connection slots are reserved"],
  ["L2|Connection leak in the new release. App team rolled back and DBA ended idle sessions with owner approval.",
   "L2|Introduced PgBouncer transaction pooling for the service."],
  apps=["order service", "customer API", "booking service"], min_priority="P2", impact_bias=1.6)

S("PG.slow", D, "PostgreSQL", "KB-0001",
  ["PostgreSQL query slow", "Postgres queries slow after data load", "Postgres statement timeout"],
  ["A query on the {app} database takes minutes instead of seconds.",
   "After last week's load our Postgres queries are slow.",
   "Reports fail with '{code}'."],
  ["canceling statement due to statement timeout"],
  ["L2|Autovacuum lagging on a large table. DBA ran VACUUM ANALYZE and tuned autovacuum.",
   "L2|Missing index added after EXPLAIN ANALYZE review."],
  apps=["analytics", "reporting", "orders"], impact_bias=1.3)

S("PG.backup", D, "PostgreSQL", "KB-0005",
  ["Postgres backup job failed", "pg_dump backup failing", "Nightly database backup failed"],
  ["The nightly PostgreSQL backup report shows a failure.",
   "Backup job for the {app} database failed with '{code}'."],
  ["backup failed", "pg_dump: error"],
  ["L2|Backup volume full. Storage expanded, backup rerun and verified with a test restore.",
   "L2|Backup user lost permissions after a role change. Grants restored and backup rerun."],
  apps=["orders", "analytics"], min_priority="P2")

S("MY.lock", D, "MySQL", "KB-0039",
  ["MySQL locking errors", "MySQL lock wait / deadlock errors", "Updates failing with MySQL lock error"],
  ["The application log shows '{code}'.",
   "Updates to the {app} tables fail during peak load.",
   "Our batch job keeps hitting a deadlock with the website."],
  ["ERROR 1205 (HY000): Lock wait timeout exceeded", "ERROR 1213 (40001): Deadlock found when trying to get lock"],
  ["L2|A long-running transaction from an admin script held locks. Owner changed the script to commit in batches.",
   "L2|Added an index to avoid range locks; deadlocks resolved."],
  apps=["e-commerce", "booking", "inventory"], impact_bias=1.4)

S("MY.replica", D, "MySQL", "KB-0040",
  ["MySQL replica lagging", "Reports showing stale data", "Read replica stopped replicating"],
  ["Reports built on the read replica are hours behind.",
   "The replica shows '{code}'.",
   "Dashboards show yesterday's numbers even though orders were placed today."],
  ["Replica_SQL_Running: No", "Seconds_Behind_Source high", "Error 1062 Duplicate entry"],
  ["L2|Replica SQL thread stopped on a duplicate key. DBA investigated and rebuilt the replica from a fresh backup.",
   "L2|Heavy batch writes caused lag. Parallel replication applier enabled after review."],
  impact_bias=1.4)

S("MY.conn", D, "MySQL", "KB-0002",
  ["MySQL too many connections", "Cannot connect to MySQL", "MySQL connections timing out"],
  ["The site shows '{code}'.",
   "Connections to MySQL time out intermittently.",
   "The {app} cannot open new database connections since the deployment."],
  ["ERROR 1040 (HY000): Too many connections", "Can't connect to MySQL server"],
  ["L2|Connection pool misconfigured in the new release. Pool size reduced and the leak fixed.",
   "L2|Network ACL change blocked port 3306 from the app subnet. Corrected through change."],
  apps=["e-commerce site", "booking service"], impact_bias=1.5)

S("MY.access", D, "MySQL", "KB-0003",
  ["MySQL access denied for user", "MySQL user cannot log in"],
  ["Login fails with '{code}'.",
   "A new analyst cannot query the MySQL reporting database."],
  ["ERROR 1045 (28000): Access denied for user"],
  ["L2|Created a least-privilege read-only user after data owner approval.",
   "L1|User was using the wrong host alias. Corrected the connection settings."])

# =============================================================================== HARDWARE
S("CPU.overheat", H, "CPU", "KB-0043",
  ["Laptop overheating", "Laptop fan always running at full speed", "Laptop very hot and slow",
   "Laptop shuts down when hot"],
  ["My laptop fan runs at full speed constantly and the bottom is very hot to touch.",
   "The laptop gets so hot it slows down and sometimes shuts off.",
   "CPU usage sits at 85-90% even with only a browser open and the fan never stops.",
   "My {app} shows '{code}' warnings and becomes sluggish."],
  ["Thermal throttling", "High CPU utilization", "CPU temperature high"],
  ["L1|Runaway search-indexing process was using 80% CPU. Ended the process and applied the update; temperatures normal.",
   "L1|Installed the approved BIOS and thermal management driver from the company portal; fan noise reduced.",
   "L2|Manufacturer diagnostics failed the fan test. Fan replaced under warranty."],
  apps=["Dell Latitude", "HP EliteBook", "Lenovo ThinkPad"])

S("CPU.memory", H, "CPU", "KB-0044",
  ["Computer low on memory warning", "Laptop very slow - memory at 95%", "Applications freezing due to low memory"],
  ["I keep getting '{code}' and apps freeze.",
   "Task Manager shows memory at 95% with just Outlook, Teams and Chrome open.",
   "My machine becomes unusable by the afternoon and needs a restart."],
  ["Your computer is low on memory", "Out of memory"],
  ["L1|A browser extension was leaking memory. Removed it; usage back to normal.",
   "L1|Disabled unnecessary startup apps and restarted; memory usage dropped by 30%.",
   "L2|8 GB RAM insufficient for the analytics workload. Hardware request approved for a 16 GB upgrade."])

S("CPU.high", H, "CPU", "KB-0030",
  ["Computer extremely slow", "High CPU usage on laptop", "CPU at 100 percent"],
  ["My laptop has become extremely slow, Task Manager shows CPU at 100%.",
   "{app} uses most of the CPU and everything else lags.",
   "The PC freezes for seconds at a time and shows '{code}'."],
  ["High CPU utilization", "Not Responding"],
  ["L1|A full antivirus scan was scheduled during working hours. Rescheduled according to policy.",
   "L1|Workbook with thousands of volatile formulas. User advised and Excel updated.",
   "L1|Stuck Windows Update service process. Restarted the device and completed the update."],
  apps=["Antimalware Service Executable", "Microsoft Teams", "Excel", "Chrome"])

S("MON.black", H, "Monitor", "KB-0008",
  ["External monitor goes black intermittently", "Second screen flickering", "Monitor blanks for a few seconds",
   "Monitor flickers after update"],
  ["My external monitor goes black for 2-3 seconds every few minutes, the laptop screen stays on.",
   "The second screen flickers since the last Windows update.",
   "The {app} connected via DisplayPort keeps losing signal for a moment."],
  ["No signal"],
  ["L1|The update had replaced the graphics driver. Installed the approved driver from the company portal; display stable.",
   "L1|Refresh rate was set above what the monitor supports. Set it to 60 Hz.",
   "L1|Faulty DisplayPort cable replaced with a certified cable."],
  apps=["Dell 27-inch monitor", "HP 24-inch monitor", "LG UltraWide monitor"])

S("MON.not_detected", H, "Monitor", "KB-0008",
  ["Monitor not detected", "External screen shows no signal", "Second monitor not working"],
  ["My {app} shows '{code}' even though it's connected.",
   "Windows does not detect my second monitor at all.",
   "The monitor works with another laptop but not mine."],
  ["No signal", "Display connection might be limited"],
  ["L1|Wrong input source selected on the monitor. Switched to DisplayPort.",
   "L1|Projection mode was set to 'PC screen only'. Set it to Extend with Win+P.",
   "L2|The laptop's USB-C port does not support DisplayPort alt mode. Provided a compatible dock."],
  apps=["Dell 27-inch monitor", "HP 24-inch monitor", "Samsung monitor"])

S("MON.dock", H, "Monitor", "KB-0011",
  ["Monitors not working through docking station", "Dock not recognising displays", "No display via dock"],
  ["Both monitors stay black when connected through the dock, but work directly.",
   "The dock charges my laptop but the screens and USB devices don't work.",
   "Windows shows '{code}' when I connect the dock."],
  ["Dock firmware update required", "Thunderbolt device functionality may be limited"],
  ["L1|Updated dock firmware from the company catalog; displays detected.",
   "L1|Dock was using an underpowered replacement adapter. Used the original power supply.",
   "L2|Dock faulty. Replaced via hardware request."])

S("MON.resolution", H, "Monitor", "KB-0008",
  ["Monitor wrong resolution", "Screen blurry on external display", "Text fuzzy on second monitor"],
  ["My external monitor is stuck at a low resolution and text is blurry.",
   "The display shows '{code}' at startup.",
   "Scaling is wrong on the second screen and I can't select the native resolution."],
  ["Unsupported mode"],
  ["L1|Set the native resolution in display settings and installed the approved graphics driver.",
   "L1|Replaced an HDMI 1.4 adapter with a certified adapter supporting the native resolution."])

S("LAP.boot", H, "Laptop", "KB-0006",
  ["Laptop won't boot", "Blue screen on startup", "Laptop stuck in restart loop"],
  ["My laptop shows a blue screen with '{code}' and restarts.",
   "The laptop powers on but never reaches the sign-in screen.",
   "After last night's update the laptop is stuck in a boot loop."],
  ["INACCESSIBLE_BOOT_DEVICE", "CRITICAL_PROCESS_DIED", "DRIVER_IRQL_NOT_LESS_OR_EQUAL"],
  ["L1|Startup Repair from the recovery environment fixed the boot problem.",
   "L2|Faulty storage driver from the update. Rolled back in Safe Mode.",
   "L2|SSD failed diagnostics. Replaced and reimaged after confirming OneDrive backup."])

S("LAP.battery", H, "Laptop", "KB-0007",
  ["Laptop battery problem", "Battery issue on laptop", "Laptop power or battery issue"],
  ["The laptop says '{code}' and stays at the same percentage.",
   "My battery goes from full to empty in about an hour.",
   "The laptop shuts down soon after I unplug the charger."],
  ["Plugged in, not charging", "Battery not detected", "AC adapter not recognized"],
  ["L1|Lower-wattage charger in use. Replaced with the approved adapter.",
   "L2|Battery report showed 40% of design capacity. Battery replaced.",
   "L1|A power-hungry app started at login. Disabled it and adjusted the power mode."])

S("LAP.disk", H, "Laptop", "KB-0045",
  ["Laptop disk warning", "Storage problem on laptop", "Disk space or drive warning"],
  ["I get '{code}' and can't save files.",
   "The C: drive has less than 1 GB free.",
   "The laptop reports '{code}' and is very slow."],
  ["Low Disk Space", "SMART: drive failure predicted", "Disk read error"],
  ["L1|Ran Storage Sense and freed 40 GB using OneDrive Files On-Demand.",
   "L2|SMART failure confirmed. Data backed up and SSD replaced."])

S("LAP.physical", H, "Laptop", "KB-0016",
  ["Laptop physically damaged", "Laptop damaged - need repair", "Broken laptop"],
  ["The screen hinge broke and the display wobbles.",
   "I dropped my laptop and the screen is cracked.",
   "I spilled coffee on the keyboard and some keys don't work."],
  [],
  ["L2|Hardware repair raised; loaner laptop issued and unit repaired under warranty.",
   "L2|Liquid damage. Device replaced after data backup."])

S("PRT.offline", H, "Printer", "KB-0009",
  ["Printer offline", "Print jobs stuck in queue", "Cannot print to floor printer"],
  ["My documents stay in the queue and the printer shows offline.",
   "The printer on {loc} shows '{code}' for everyone.",
   "Nothing prints, the queue just says error."],
  ["Printer offline", "Print job stuck", "0x0000011b"],
  ["L1|Cleared the stuck job and re-added the printer from the print server.",
   "L2|Printer IP changed after DHCP lease renewal. Reservation added and the queue updated.",
   "L1|'Use Printer Offline' was enabled. Turned it off."],
  envs=["office"], impact_bias=1.5)

S("PRT.quality", H, "Printer", "KB-0010",
  ["Printer output problem", "Print quality issue", "Printouts not correct"],
  ["The printer feeds paper but the pages come out blank.",
   "Printouts have random symbols instead of text.",
   "PDFs print with '{code}' at the top of the page."],
  ["PCL XL error", "PostScript error"],
  ["L1|New toner cartridge seal had not been removed. Fixed.",
   "L2|Wrong driver deployed for the model. Support deployed the approved model driver."],
  envs=["office"])

S("PRT.scan", H, "Printer", None,
  ["Scan to email not working", "Scanner not sending documents", "Scans never arrive"],
  ["Scan to email on the floor printer stopped working.",
   "Scanned documents never arrive in my inbox.",
   "The printer shows '{code}' when I scan to email."],
  ["SMTP authentication failed"],
  ["L2|SMTP relay credentials for the device had expired. Updated by the print team.",
   "L2|Mail relay blocked the new printer IP. Added to the approved relay list."],
  envs=["office"], impact_bias=1.4)

S("KM.bt", H, "Keyboard/Mouse", "KB-0012",
  ["Bluetooth keyboard or mouse problem", "Wireless mouse or keyboard issue", "Bluetooth peripheral disconnecting"],
  ["My Bluetooth mouse freezes and disconnects several times a day.",
   "The keyboard doesn't show up when I try to pair it, it says '{code}'.",
   "The mouse pointer lags and jumps around."],
  ["Pairing failed", "Bluetooth device not found"],
  ["L1|Replaced batteries and re-paired the device.",
   "L1|Removed the stale pairing and added the device again.",
   "L1|Moved the receiver away from a USB 3 hub causing interference."])

S("KM.usb", H, "Keyboard/Mouse", "KB-0046",
  ["Keyboard problem", "USB keyboard issue", "Keyboard input problem"],
  ["My USB keyboard is not detected and Windows says '{code}'.",
   "When I type @ I get a different character.",
   "Some keys type the wrong symbols since yesterday."],
  ["USB device not recognized", "Unknown USB Device (Device Descriptor Request Failed)"],
  ["L1|Removed an extra keyboard layout and set the correct one.",
   "L1|Connected directly instead of through an unpowered hub; detected.",
   "L2|Keyboard faulty. Replaced via hardware request."])

S("KM.builtin", H, "Keyboard/Mouse", "KB-0046",
  ["Laptop keyboard or touchpad not working", "Built-in keyboard or touchpad issue", "Laptop input not responding"],
  ["A few keys on my laptop keyboard stopped working.",
   "The touchpad doesn't respond but an external mouse works.",
   "My touchpad stopped working after I pressed some function keys."],
  [],
  ["L1|Touchpad had been disabled with a function key. Re-enabled it.",
   "L2|Built-in keyboard failure. Repair ticket raised and keyboard replaced."])

# =============================================================================== SOFTWARE
S("EM.crash", SW, "Email", "KB-0029",
  ["Outlook keeps crashing", "Outlook crash", "Outlook closes unexpectedly"],
  ["Outlook crashes immediately whenever I open or preview an attachment.",
   "Outlook closes a few seconds after starting and Event Viewer shows '{code}'.",
   "Outlook crashes when I open a particular email."],
  ["Faulting application name: OUTLOOK.EXE", "Exception code 0xc0000005", "Application Error event 1000"],
  ["L1|A faulty add-in was disabled; Outlook stable.",
   "L1|Quick Repair of Office from Settings > Apps resolved the crash.",
   "L2|Office update build regression. Rolled back to the previous build through the managed channel."])

S("EM.full", SW, "Email", "KB-0047",
  ["Mailbox full cannot send", "Mailbox quota exceeded", "Emails bouncing - mailbox full"],
  ["Outlook says '{code}' and I can't send emails.",
   "Colleagues say their emails to me are bouncing with '{code}'.",
   "I get a warning that my mailbox is almost full every day."],
  ["Your mailbox is full", "550 5.2.2 mailbox full", "Mailbox quota exceeded"],
  ["L1|Emptied Deleted Items and moved old items to the Online Archive.",
   "L2|Quota increase approved for the role and applied."])

S("EM.disconnected", SW, "Email", "KB-0048",
  ["Outlook not syncing", "Outlook disconnected from server", "Outlook connection problem"],
  ["Outlook shows '{code}' in the status bar and no new mail arrives.",
   "Outlook keeps prompting for my password since I changed it.",
   "Webmail works but desktop Outlook won't sync."],
  ["Disconnected", "Trying to connect...", "Need Password"],
  ["L1|Removed old cached credentials and signed in again.",
   "L1|Work Offline was enabled. Turned it off.",
   "L1|Recreated the Outlook profile; sync restored."])

S("EM.mobile", SW, "Email", "KB-0015",
  ["Email not syncing on phone", "Cannot set up work email on mobile", "Phone mail says device not compliant"],
  ["My work email stopped syncing on my phone.",
   "The mail app says '{code}' when I add my work account."],
  ["Device not compliant", "Account setup incomplete"],
  ["L1|Device was not enrolled. Enrolled in Company Portal and set up Outlook mobile."])

S("OS.update", SW, "Operating System", "KB-0049",
  ["Windows update failing", "Updates fail with '{code}'", "Stuck on Windows update"],
  ["Windows Update fails every time with '{code}'.",
   "The update keeps rolling back after restart.",
   "I get a notification that my device is missing important updates."],
  ["0x800f0922", "0x80070002", "0x8024402c"],
  ["L1|Freed disk space and reran the update.",
   "L2|Ran DISM and SFC; update installed.",
   "L1|Connected to VPN so the device could reach WSUS; update completed."])

S("OS.profile", SW, "Operating System", "KB-0050",
  ["Signed in with temporary profile", "Desktop files missing after login", "User profile service failed"],
  ["After logging in all my desktop files are gone and it says '{code}'.",
   "Windows says '{code}' at sign-in.",
   "My settings reset every time I sign in."],
  ["You've been signed in with a temporary profile", "The User Profile Service failed the sign-in"],
  ["L2|Corrected the profile registry entry using the supported procedure; profile restored.",
   "L2|Profile corrupted. New profile created and data restored from OneDrive."])

S("OS.slow_boot", SW, "Operating System", "KB-0044",
  ["Windows very slow to start", "Slow login", "Takes ages to reach desktop"],
  ["It takes 10 minutes from power on to desktop.",
   "Windows is very slow after the latest update.",
   "Signing in sits on 'Preparing Windows' for a long time."],
  [],
  ["L1|Disabled unnecessary startup apps; boot time normal.",
   "L2|Group Policy processing delayed by an unreachable logon script. Script path fixed."])

S("OS.bsod", SW, "Operating System", "KB-0006",
  ["Blue screen during work", "Random restarts", "Windows crashes randomly"],
  ["Windows crashes with a blue screen '{code}' a few times a week.",
   "My PC restarts randomly while I'm working.",
   "I lost work twice today because Windows suddenly restarted with '{code}'."],
  ["DRIVER_IRQL_NOT_LESS_OR_EQUAL", "MEMORY_MANAGEMENT"],
  ["L2|Faulty network driver rolled back.",
   "L2|Memory diagnostic failed. RAM replaced."])

S("INST.admin", SW, "Installation", "KB-0026",
  ["Need admin rights to install software", "Installation requires administrator", "Can't install {app}"],
  ["The installer for {app} says I need administrator rights.",
   "Installing {app} rolls back with '{code}'.",
   "I downloaded {app} but can't install it."],
  ["Error 1603", "Installation requires elevated privileges", "Error 5"],
  ["L1|Installed the approved package from Software Center.",
   "L2|Package not in the catalog. Software request approved and the endpoint team deployed it."],
  apps=["Python 3.12", "Tableau Desktop", "Notepad++", "Zoom", "Git"])

S("INST.conflict", SW, "Installation", "KB-0027",
  ["Installer says another installation in progress", "Cannot update - older version present", "MSI install error"],
  ["Setup fails with '{code}'.",
   "I can't upgrade {app}, it says a newer version is already installed.",
   "{app} appears twice in installed apps and won't reinstall."],
  ["MSI error 1618", "MSI error 1638", "MSI error 1605"],
  ["L1|Restarted to clear the pending installer; install succeeded.",
   "L2|Endpoint team used the vendor cleanup tool and reinstalled the approved version."],
  apps=["Adobe Acrobat Reader", "Java Runtime", "7-Zip", "Microsoft Visio"])

S("INST.blocked", SW, "Installation", "KB-0028",
  ["Installer blocked by antivirus", "App blocked by your organization", "Setup file quarantined"],
  ["Endpoint protection quarantines the {app} installer.",
   "Windows says '{code}' when I run setup.",
   "The {app} setup file disappears right after download."],
  ["App blocked by administrator", "0x800704EC", "Threat quarantined"],
  ["L2|Security review found an unsigned installer. Signed vendor version approved and deployed.",
   "L2|Request rejected; an approved alternative tool was provided."],
  apps=["a PDF converter", "a screen recorder", "a database client", "a file sync tool"])

S("APP.crash", SW, "Application Error", "KB-0029",
  ["{app} crashes on startup", "Missing DLL error", "Application closes immediately"],
  ["{app} opens and closes immediately.",
   "I get '{code}' when starting {app}.",
   "{app} crashed after the update and won't open."],
  ["VCRUNTIME140.dll was not found", ".NET Runtime error", "Application Error event 1000"],
  ["L1|Repaired the installation from Software Center.",
   "L2|Installed the required Visual C++ runtime from the approved package."],
  apps=["SAP GUI", "Power BI Desktop", "AutoCAD", "the expense tool"])

S("APP.freeze", SW, "Application Error", "KB-0030",
  ["{app} not responding", "{app} freezes when opening large file", "{app} hangs"],
  ["{app} freezes for minutes with '{code}'.",
   "{app} hangs whenever I open a large file.",
   "{app} becomes unresponsive after about an hour of use."],
  ["Not Responding", "Application Hang event 1002"],
  ["L1|Disabled a faulty add-in.",
   "L1|Updated to the latest approved version.",
   "L2|Vendor confirmed a defect with large files; hotfix deployed."],
  apps=["Excel", "SAP GUI", "Power BI Desktop", "Teams"])

S("APP.error", SW, "Application Error", None,
  ["Error when saving in {app}", "{app} shows unexpected error", "{app} error on submit"],
  ["{app} shows an unexpected error when I save my work.",
   "I get '{code}' in {app} after clicking submit.",
   "{app} throws an error on one specific form."],
  ["Unhandled exception", "Object reference not set to an instance of an object"],
  ["L2|Bug in the latest release. Vendor hotfix applied.",
   "L2|Corrupted local cache cleared by application support."],
  apps=["the CRM desktop client", "the quoting tool", "the claims app"])

S("COL.av", SW, "Collaboration Tools", "KB-0051",
  ["Camera or microphone not working in {app}", "Audio or video problem in {app} meetings", "Others can't hear or see me in {app}"],
  ["In {app} meetings it says '{code}'.",
   "People can't hear me in meetings but my headset works for music.",
   "My camera shows a black screen in {app}."],
  ["No camera detected", "We can't find a microphone", "Camera is being used by another app"],
  ["L1|Camera privacy setting was off. Enabled camera access for desktop apps.",
   "L1|Wrong device selected in the app settings. Selected the headset.",
   "L1|Another app was holding the camera. Closed it and restarted the meeting app."],
  apps=["Microsoft Teams", "Zoom", "Webex"])

S("COL.sync", SW, "Collaboration Tools", "KB-0052",
  ["OneDrive not syncing", "SharePoint files not syncing", "OneDrive sync pending forever"],
  ["OneDrive has been stuck on '{code}' for hours.",
   "Files I save don't appear for my colleagues on SharePoint.",
   "OneDrive shows sync errors on several files."],
  ["Sync pending", "0x8004de40", "Can't sync this file"],
  ["L1|Renamed files with invalid characters; sync completed.",
   "L1|Signed in again to OneDrive; sync resumed.",
   "L2|Reset OneDrive as instructed by IT; sync completed."])

S("COL.voip", SW, "Collaboration Tools", "KB-0013",
  ["Poor call quality", "Echo on calls", "Voice breaking up in meetings"],
  ["People say my voice is robotic and breaking up.",
   "There's an echo on every call.",
   "Call quality drops and the network panel shows '{code}'."],
  ["RTP packet loss"],
  ["L1|Moved to a wired connection; call quality normal.",
   "L2|QoS misconfiguration on the floor switch fixed by NET-OPS."],
  impact_bias=1.3)

S("COL.join", SW, "Collaboration Tools", "KB-0051",
  ["Cannot join Teams meeting", "Teams stuck on loading", "Meeting app won't open"],
  ["Teams is stuck loading and I can't join meetings.",
   "Joining a meeting fails with '{code}'.",
   "{app} opens a blank window when I click a meeting link."],
  ["Something went wrong"],
  ["L1|Cleared the Teams cache and updated the client.",
   "L1|Signed out and back in; joined successfully."],
  apps=["Microsoft Teams", "Zoom"])

# ======================================================================= ACCESS & SECURITY
S("PW.expired", AS, "Password Reset", "KB-0053",
  ["Password reset needed", "Cannot sign in - password issue", "Need password reset"],
  ["Windows says '{code}' and won't let me in.",
   "I forgot my password after my holiday.",
   "The new password I choose is always rejected with '{code}'."],
  ["Your password has expired and must be changed", "Password does not meet complexity requirements"],
  ["L1|Guided the user through the self-service password reset portal.",
   "L1|Identity verified; temporary password issued and changed at next sign-in."])

S("PW.sync", AS, "Password Reset", "KB-0053",
  ["Old password still asked after change", "Password change not working everywhere", "New password not accepted on laptop"],
  ["After changing my password, my phone and laptop keep asking for the old one.",
   "My new password works on webmail but my laptop says '{code}'.",
   "Since the reset, only some apps accept my new password."],
  ["The user name or password is incorrect"],
  ["L1|Laptop was off-network during the change. Connected to VPN and locked/unlocked to cache the new password.",
   "L1|Updated the saved password in the mobile mail app."])

S("PW.service", AS, "Password Reset", "KB-0004",
  ["Service account password expired", "Scheduled job failing after password rotation"],
  ["The {app} scheduled task fails since the service account password was rotated.",
   "Our integration stopped working and the logs show '{code}'."],
  ["Logon failure: unknown user name or bad password", "password expired"],
  ["L2|Owner updated the secret in the vault and the task configuration."],
  apps=["backup", "ETL", "reporting"])

S("LOCK.repeat", AS, "Account Lockout", "KB-0054",
  ["Account keeps getting locked", "Locked out again", "Account locked every morning"],
  ["My account gets locked several times a day.",
   "Windows says '{code}'.",
   "Since changing my password I keep getting locked out."],
  ["The referenced account is currently locked out", "Account locked"],
  ["L1|Stale credentials in the mobile mail app removed; account unlocked.",
   "L2|Lockout source traced via Event ID 4740 to old mapped-drive credentials on a second laptop; cleared.",
   "L3|Lockouts came from external IPs. Security investigated password spraying and enforced a reset."])

S("LOCK.disabled", AS, "Account Lockout", "KB-0054",
  ["Account disabled", "Cannot log in - account disabled"],
  ["Windows says '{code}' after I came back from leave.",
   "My contract was extended but my account is disabled."],
  ["Your account has been disabled. Please see your system administrator."],
  ["L2|Manager confirmed the extension; IAM re-enabled the account."])

S("LOCK.app", AS, "Account Lockout", "KB-0003",
  ["Locked out of {app}", "{app} account locked"],
  ["I'm locked out of {app} after too many attempts.",
   "{app} says '{code}'."],
  ["User locked", "Account locked"],
  ["L1|Unlocked by the application administrator after identity verification."],
  apps=["SAP", "the HR portal", "Salesforce"])

S("MFA.push", AS, "MFA", "KB-0055",
  ["Not receiving MFA notifications", "Authenticator approval timed out", "MFA push not arriving"],
  ["I'm not receiving the Authenticator push notifications, sign-in says '{code}'.",
   "The approval request times out before my phone shows it.",
   "MFA notifications stopped after the phone update."],
  ["We didn't receive a response", "Approval request timed out"],
  ["L1|Enabled notifications and disabled battery optimisation for the app.",
   "L1|Signed in with the one-time code and re-registered the app."])

S("MFA.newphone", AS, "MFA", "KB-0017",
  ["Need MFA reset - can't approve sign-ins", "Authenticator not available on my phone", "MFA method needs re-registering"],
  ["I got a new phone and can't approve sign-ins anymore.",
   "I lost my phone with the Authenticator app.",
   "Sign-in keeps saying '{code}' and my old phone was reset."],
  ["Additional authentication required"],
  ["L1|Identity verified; MFA reset and the new phone registered.",
   "L2|Lost device: sessions revoked and device wiped per policy; MFA reset."])

S("MFA.fatigue", AS, "MFA", "KB-0055",
  ["Unexpected MFA prompts I didn't request", "Getting MFA requests at night", "Suspicious sign-in approval requests"],
  ["I keep getting MFA approval requests I didn't start.",
   "My phone shows sign-in requests from a location I've never been to.",
   "I received '{code}' notifications at 3 am."],
  ["Unexpected sign-in request"],
  ["L3|Security confirmed password compromise. Reset password, revoked sessions and blocked the source IPs.",
   "L2|An old device was retrying sign-in. Device removed from the account."],
  min_priority="P2")

S("AR.app", AS, "Access Request", "KB-0056",
  ["Request access to {app}", "Need access to {app}", "Access to {app} for new role"],
  ["I need access to {app} for my new role.",
   "Please give me access to {app}.",
   "I get '{code}' when opening {app}."],
  ["You need permission to access this resource", "Access denied"],
  ["L1|Access request submitted and approved by the owner; user added to the group.",
   "L2|Owner rejected full access; least-privilege read access granted instead."],
  apps=["the Finance SharePoint site", "the Sales shared mailbox", "the Power BI workspace", "the Jira project", "the HR portal"],
  intent="request")

S("AR.share", AS, "Access Request", "KB-0025",
  ["Access to network folder", "Need write access to team share", "Folder access for new joiner"],
  ["I need write access to the {app} folder.",
   "A new team member needs access to our department share.",
   "Please add me to the {app} share."],
  [],
  ["L2|Owner approved; user added to the security group."],
  apps=["Projects", "Finance", "Marketing"], intent="request")

S("AR.db", AS, "Access Request", "KB-0003",
  ["Need read access to reporting database", "Database access request"],
  ["I need read-only access to the {app} database for reporting.",
   "Please grant me query access to the {app} data mart."],
  [],
  ["L2|DBA granted a read-only role after data owner approval."],
  apps=["sales", "inventory", "HR analytics"], intent="request")

S("PH.report", AS, "Phishing/Malware", "KB-0057",
  ["Suspicious email received", "Possible phishing email", "Is this email legitimate?"],
  ["I received an email claiming to be from IT asking me to verify my password.",
   "An email with an unexpected invoice attachment arrived from an unknown sender.",
   "I got a message that my mailbox will be deleted unless I click a link."],
  [],
  ["L1|Reported with the Report Phishing button; security confirmed phishing and purged it from all mailboxes.",
   "L1|Security confirmed the email was from a legitimate vendor."],
  min_priority="P3", impact_bias=1.2)

S("PH.clicked", AS, "Phishing/Malware", "KB-0057",
  ["Interacted with a phishing email", "Possible compromise after phishing email", "I clicked something in a suspicious email"],
  ["I clicked a link in an email and entered my password before realising it was fake.",
   "I opened an attachment from an unknown sender and now I'm worried.",
   "I approved an MFA request after clicking a link in an email."],
  [],
  ["L2|Password reset, sessions revoked and sign-in logs reviewed; no further activity.",
   "L3|An attacker-created mailbox forwarding rule was found and removed; incident handled by SEC-OPS."],
  min_priority="P2", impact_bias=0.25)

S("MW.alert", AS, "Phishing/Malware", "KB-0058",
  ["Antivirus detected a threat", "Malware alert on laptop", "Threat quarantined pop-up"],
  ["Endpoint protection says '{code}' on my laptop.",
   "A pop-up says a threat was detected and quarantined.",
   "I keep getting '{code}' alerts after plugging in a USB stick."],
  ["Threat quarantined", "Threat detected"],
  ["L2|Single quarantined detection from a downloaded file. Full scan clean; user briefed.",
   "L3|Device isolated by SEC-OPS through EDR, reimaged and files restored from backup."],
  min_priority="P2")

S("MW.ransom", AS, "Phishing/Malware", "KB-0058",
  ["Ransomware - files encrypted", "Files encrypted with ransom note", "Shared drive files renamed"],
  ["My files have been renamed with strange extensions and there is a ransom note on the desktop.",
   "Shared drive files are being encrypted and I see '{code}'.",
   "Documents on the team share won't open and have a new extension."],
  ["Ransomware behavior blocked", "Files encrypted"],
  ["L3|SEC-OPS isolated the device and share, restored data from backups and filed an incident report."],
  min_priority="P1", impact_bias=1.8, weight=0.5)

# ============================================================================ INQUIRY/HELP
S("HT.mobile_email", IH, "How-To", "KB-0015",
  ["How do I set up email on my phone?", "Work email on new phone", "Set up Outlook on mobile"],
  ["How do I set up my work email on my new phone?",
   "Can someone explain how to add my work email to my Android phone?",
   "What are the steps to get Outlook working on my iPhone?"],
  [], ["L1|Shared the mobile setup guide; user enrolled the device and set up Outlook mobile."],
  intent="how_to")

S("HT.calendar", IH, "How-To", None,
  ["How do I share my calendar?", "Share calendar with team", "Calendar delegate access"],
  ["Can someone explain how to share my calendar with my team?",
   "How do I give my assistant access to manage my calendar?",
   "How can my team see my free/busy times?"],
  [], ["L1|Walked the user through Outlook > Calendar > Share and delegate permissions."],
  intent="how_to")

S("HT.ooo", IH, "How-To", None,
  ["How do I set an out-of-office reply?", "Automatic replies setup", "Out of office message"],
  ["How do I set an automatic out-of-office reply?",
   "Can I schedule my out-of-office message for next week?",
   "How do I turn on automatic replies from my phone?"],
  [], ["L1|Shared the automatic replies guide; user configured scheduled replies."],
  intent="how_to")

S("HT.meeting_room", IH, "How-To", None,
  ["How to connect to meeting room display?", "Present on meeting room screen", "Meeting room screen sharing"],
  ["How do I connect my laptop to the meeting room screen on {loc}?",
   "What's the way to share my screen wirelessly in the conference room?",
   "How do I join the room system to a Teams meeting?"],
  [], ["L1|Explained the room panel and casting steps; user presented successfully."],
  envs=["office"], intent="how_to")

S("HT.mfa_setup", IH, "How-To", "KB-0017",
  ["How do I set up MFA?", "Set up Authenticator app", "Add a backup MFA method"],
  ["How do I set up the Authenticator app for sign-in?",
   "How can I add a backup verification method?",
   "I'm a new joiner, how do I register for MFA?"],
  [], ["L1|Shared the security-information portal guide; user registered the app and a backup method."],
  intent="how_to")

S("SR.new", IH, "Software Request", "KB-0014",
  ["Request to install {app}", "Need {app} license", "Software request: {app}"],
  ["I need {app} installed for a project.",
   "Can I get a license for {app}?",
   "Please install {app}, it's not in Software Center."],
  [],
  ["L1|Approved package installed from Software Center.",
   "L2|License procured after manager approval and deployed by the endpoint team.",
   "L2|Request rejected by security review; approved alternative suggested."],
  apps=["Tableau", "Microsoft Visio", "Adobe Acrobat Pro", "MATLAB", "Postman", "Figma"], intent="request")

S("SR.upgrade", IH, "Software Request", "KB-0014",
  ["Upgrade {app} to latest version", "Need newer version of {app}"],
  ["Can {app} be upgraded to the latest version?",
   "I need a newer version of {app} for a feature our client uses."],
  [], ["L1|Deployed the approved newer version through Software Center."],
  apps=["Python", "Power BI Desktop", "Notepad++", "Microsoft Project"], intent="request")

S("HR.peripheral", IH, "Hardware Request", "KB-0016",
  ["Request for a {app}", "Need a new {app}", "Can I get a {app}?"],
  ["I'd like to request a {app} for my desk.",
   "My {app} is broken, can I get a replacement?",
   "I need a {app} for working from home."],
  [],
  ["L1|Request approved and the item issued from stock.",
   "L2|Item ordered after manager approval and delivered."],
  apps=["second monitor", "headset", "docking station", "ergonomic keyboard", "laptop stand", "webcam"],
  intent="request")

S("HR.refresh", IH, "Hardware Request", "KB-0016",
  ["Laptop replacement eligibility", "When is my laptop due for refresh?", "Request new laptop"],
  ["My laptop is over four years old, can I get a new one?",
   "Is my device eligible for a refresh?",
   "My laptop can't run the tools I need anymore, can I request a replacement?"],
  [], ["L1|Asset record checked; device eligible next quarter and refresh scheduled.",
       "L2|Asset management approved early replacement for the role."],
  intent="request")

S("AV.defs", IH, "Antivirus", "KB-0059",
  ["Antivirus definitions out of date", "Antivirus not updating", "Protection update failed"],
  ["My antivirus shows '{code}'.",
   "Antivirus says protection is out of date and won't update.",
   "Windows Security shows a warning that '{code}'."],
  ["Definitions out of date", "Security intelligence update failed"],
  ["L1|Connected to VPN and checked for updates; definitions current.",
   "L2|Security agent unhealthy. Reinstalled through managed deployment."])

S("AV.howto", IH, "Antivirus", "KB-0059",
  ["Antivirus scan question", "Question about antivirus scans", "How do antivirus scans work here?"],
  ["How do I run a full antivirus scan on my laptop?",
   "Can I change the time of the automatic antivirus scan?",
   "Is it safe to scan a USB stick before opening it, and how?"],
  [], ["L1|Explained how to run a scan; schedules are managed centrally by policy."],
  intent="how_to")

S("AV.false_pos", IH, "Antivirus", "KB-0028",
  ["Antivirus flags a work file", "False positive on internal tool", "Antivirus blocking work spreadsheet"],
  ["The antivirus keeps flagging our internal tool as a threat.",
   "A work spreadsheet is quarantined with '{code}' every time I download it.",
   "Our team macro file is removed by the antivirus."],
  ["Threat quarantined", "Potentially unwanted application blocked"],
  ["L2|SEC-OPS confirmed a false positive and created a scoped exclusion.",
   "L2|File contained an unsigned macro. Developer signed it and SEC-OPS approved it."])

S("IA.error", IH, "Internal Application", "KB-0060",
  ["{app} error", "{app} not loading", "Problem accessing {app}", "{app} shows HTTP error"],
  ["{app} shows '{code}' when I log in.",
   "{app} keeps redirecting and never loads.",
   "{app} is down for everyone in my team, it shows '{code}'."],
  ["HTTP 500 Internal Server Error", "HTTP 403 Forbidden", "ERR_TOO_MANY_REDIRECTS", "HTTP 503 Service Unavailable"],
  ["L1|Cleared site cookies and signed in again; redirect loop fixed.",
   "L2|Application outage. App support restarted the service.",
   "L2|403 caused by a missing role. Access request completed."],
  apps=["the expense portal", "the leave management portal", "the timesheet app", "the procurement portal"],
  impact_bias=1.4)

S("IA.howto", IH, "Internal Application", None,
  ["How do I use {app}?", "Help with {app}", "Where do I find this in {app}?"],
  ["How do I submit a request in {app}?",
   "Where can I find my history in {app}?",
   "Is there a guide for {app}? I'm new to it."],
  [], ["L1|Shared the user guide link and walked through the steps."],
  apps=["the expense portal", "the leave management portal", "the timesheet app", "the procurement portal"],
  intent="how_to")


TAXONOMY = {
    "Network": ["VPN", "Wireless", "DNS/DHCP", "Firewall", "Network Drive"],
    "Database": ["Oracle", "MS SQL Server", "DB2", "PostgreSQL", "MySQL"],
    "Hardware": ["CPU", "Monitor", "Laptop", "Printer", "Keyboard/Mouse"],
    "Software": ["Email", "Operating System", "Installation", "Application Error", "Collaboration Tools"],
    "Access & Security": ["Password Reset", "Account Lockout", "MFA", "Access Request", "Phishing/Malware"],
    "Inquiry/Help": ["How-To", "Software Request", "Hardware Request", "Antivirus", "Internal Application"],
}

_have = {(s.category, s.subcategory) for s in SCENARIOS}
for _c, _subs in TAXONOMY.items():
    for _s in _subs:
        assert (_c, _s) in _have, f"no scenario for {_c}/{_s}"
assert all(s.subcategory in TAXONOMY[s.category] for s in SCENARIOS)
