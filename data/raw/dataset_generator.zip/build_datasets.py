"""Build the synthetic datasets.

Outputs (in --out):
  articles.json            KEDB: original 30 articles (unchanged) + 30 new (KB-0031..KB-0060)
  tickets.json             1,500 tickets in the processed schema (ready for ChromaDB)
  Dataset_ticket_5.xlsx    same tickets as a rich spreadsheet + Summary + Data Dictionary + KB Coverage
  taxonomy_map.yaml        ticket subcategory -> primary/secondary KB ids (derived from scenarios)

Usage: python gen/build_datasets.py --articles <original articles.json> --out <dir>
Deterministic: seed 42.
"""
import argparse
import json
import math
import random
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from kb_new import NEW_ARTICLES  # noqa: E402
from scenarios import SCENARIOS, TAXONOMY  # noqa: E402

SEED = 42
PER_SUBCATEGORY = 50
DUPLICATES_PER_SUBCATEGORY = 3
START = datetime(2026, 5, 1)
END = datetime(2026, 10, 31, 23, 59)
SNAPSHOT = datetime(2026, 11, 15)

LOCS = ["Building A, 3rd floor", "Building B, 2nd floor", "Building C, ground floor",
        "Pune campus, Tower 2, 4th floor", "Bengaluru office, 5th floor", "Hyderabad office, 1st floor",
        "Chennai office, 6th floor", "Noida campus, Block D"]
DEPTS = ["Finance", "HR", "Sales", "Operations", "Customer Support", "Engineering", "Procurement",
         "Marketing", "Legal", "Supply Chain"]
FIRST = ["Aarav", "Diya", "Rohan", "Priya", "Karan", "Ananya", "Vikram", "Neha", "Arjun", "Sara",
         "Rahul", "Meera", "John", "Emma", "Ravi", "Fatima"]
LAST = ["Sharma", "Iyer", "Patel", "Reddy", "Nair", "Gupta", "Khan", "Das", "Smith", "Fernandes",
        "Menon", "Joshi"]

ONSET = {
    "_": ["since this morning", "since yesterday afternoon", "for the past two days", "since Monday",
          "intermittently over the last week", "since I came back from leave", "for about an hour now",
          "since the office move last week"],
    "Database": ["since last night's deployment", "after the weekend maintenance window",
                 "since the data load on Friday", "since this morning"],
    "Access & Security": ["since I changed my password", "since this morning", "since yesterday"],
    "Software": ["since the latest Office update", "since the Windows update last night", "since this morning",
                 "for the past two days"],
}
ONSET_TPL = ["It has been happening {onset}.", "This has been going on {onset}.", "I've had this problem {onset}."]
TRIED = {
    "Network": ["I already restarted my laptop.", "I tried reconnecting a couple of times.",
                "Restarting my home router didn't help.", "I tried another network and got the same result."],
    "Database": ["The DBA checked and there are no locks.", "We restarted the application but it didn't help.",
                 "Re-running the job gives the same error.", "I cleared the client cache and tried again."],
    "Hardware": ["I've already restarted the laptop.", "I tried unplugging and reconnecting it.",
                 "I checked that the cables are firmly connected.", "It works on my colleague's laptop."],
    "Software": ["I've restarted the application and my laptop.", "I tried repairing it from Settings but no luck.",
                 "Reinstalling didn't help.", "Webmail works fine."],
    "Access & Security": ["I tried the self-service portal already.", "I restarted my phone.",
                          "I tried signing out and back in."],
    "Inquiry/Help": [],
}
REQUEST_CTX = ["I joined the {dept} team last week.", "My manager has already approved this.",
               "It's needed for an upcoming project.", "Colleagues in {dept} already have this.",
               "I'm new and couldn't find this in the knowledge base."]
IMPACT_TPL = {
    3: ["Only my machine seems to be affected.", "My colleagues are not having this issue.",
        "It's just me as far as I know."],
    2: ["{n} people in my team are seeing the same thing.", "Several colleagues on {loc} report the same problem.",
        "At least {n} of us in {dept} are affected.", "Multiple colleagues have reported the same issue."],
    1: ["About {n} users across {dept} are affected.", "This is affecting the whole {dept} department, around {n} people.",
        "We have {n}+ users unable to work.", "Approximately {n} users are affected."],
}
URGENCY_TPL = {
    3: ["No rush, whenever someone is available.", "Not urgent but annoying."],
    2: ["I have a client presentation later this week.", "I have a workaround for now but it slows me down.",
        "We need this fixed before Friday.", "It's affecting my work but I can still do some tasks."],
    1: ["I have a deadline today.", "This is blocking month-end close for {dept}.", "I cannot work at all.",
        "Customer-facing orders are failing.", "I have critical client proposals due by end of day.",
        "Production processing is stopped."],
}
REQUEST_URGENCY = {3: ["Whenever possible.", "Needed within the next two weeks."],
                   2: ["I need it by Friday for a client deliverable."]}
VAGUE = {
    "VPN": ["Can't get into the company network from home.", "Remote access not working."],
    "Wireless": ["Internet keeps cutting out in the office.", "Connection is unstable in the meeting room."],
    "DNS/DHCP": ["Network not working at my desk.", "Some internal sites won't open."],
    "Firewall": ["A website I need isn't loading.", "The app can't reach its server."],
    "Network Drive": ["Can't get to my team's files.", "The shared folder isn't there."],
    "Oracle": ["The report is really slow today.", "The finance database app keeps erroring."],
    "MS SQL Server": ["Can't open the customer database.", "The reporting database app keeps erroring."],
    "DB2": ["The batch job failed again overnight.", "Claims system is erroring when saving."],
    "PostgreSQL": ["The analytics app can't reach its database.", "Our service is throwing database errors."],
    "MySQL": ["The website database seems stuck.", "Reports show old numbers."],
    "CPU": ["My laptop is really slow and loud.", "Computer is crawling today."],
    "Monitor": ["My screen keeps going off.", "Display issue at my desk."],
    "Laptop": ["My laptop won't start properly.", "Laptop problem, need help."],
    "Printer": ["Can't print.", "Printer not working again."],
    "Keyboard/Mouse": ["Mouse not working.", "Keyboard acting weird."],
    "Email": ["Email not working.", "Outlook problem again."],
    "Operating System": ["Windows is acting up after the update.", "Computer restarted by itself."],
    "Installation": ["Can't install the software I need.", "Install keeps failing."],
    "Application Error": ["The app keeps crashing.", "Getting an error in the application."],
    "Collaboration Tools": ["Teams isn't working properly.", "Problem with my meeting."],
    "Password Reset": ["Can't log in.", "My password isn't working."],
    "Account Lockout": ["I'm locked out.", "Can't get into my account this morning."],
    "MFA": ["Sign-in verification isn't working.", "Not getting the code on my phone."],
    "Access Request": ["I need access please.", "Can't open the team site, need permission."],
    "Phishing/Malware": ["Got a weird email.", "Something strange popped up on my laptop."],
    "How-To": ["Quick question about Outlook.", "Need help with a setting."],
    "Software Request": ["Need a new tool installed.", "Can I get some software?"],
    "Hardware Request": ["Need new equipment.", "Can I get an accessory for my desk?"],
    "Antivirus": ["Question about the antivirus.", "Antivirus warning on my laptop."],
    "Internal Application": ["The portal isn't working.", "Internal site giving an error."],
}
VAGUE_SUFFIX = ["", " Please help.", " Any idea?", " Thanks.", " Can someone check?"]
VAGUE_PER_SUBCATEGORY = 3
NOISE = ["I'm connected through VPN from home.", "I'm on the office WiFi.", "I already restarted Outlook and Teams.",
         "My laptop was replaced last month.", "I'm using Chrome.", "This is on my Windows 11 laptop.",
         "My password was changed last week.", "I'm working on the finance report in Excel.",
         "I logged in with MFA as usual.", "I'm using the docking station at my desk."]
OPENERS = ["Hi team,", "Hello,", "Hi IT,", "Good morning,", "Hi,"]
CLOSERS = ["Thanks.", "Please help.", "Can someone take a look?", "Thanks in advance.", "Please advise."]
CODE_TPL = ["The error says '{code}'.", "I get the message \"{code}\".", "Error shown: {code}.",
            "The log shows '{code}'."]
LOC_TPL = {"office": ["I'm on {loc}.", "I sit on {loc}."],
           "remote": ["I'm working from home.", "I'm working remotely today."]}

# Priority matrix (impact x urgency). Incidents are floored at P3; requests/how-to are not floored.
MATRIX = {(1, 1): "P1", (1, 2): "P2", (1, 3): "P2",
          (2, 1): "P2", (2, 2): "P2", (2, 3): "P3",
          (3, 1): "P2", (3, 2): "P3", (3, 3): "P3"}
LEVEL = {"P1": "Critical", "P2": "High", "P3": "Medium", "P4": "Low"}
SEV = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}

SPECIALIST = {"Network": "NET-OPS", "Database": "DBA", "Hardware": "EUC-HW", "Software": "EUC-SW",
              "Access & Security": "IAM", "Inquiry/Help": "SERVICE-DESK"}
SPECIALIST_SUB = {"Phishing/Malware": "SEC-OPS", "Antivirus": "SEC-OPS", "Internal Application": "APP-SUPPORT",
                  "Software Request": "EUC-SW", "Hardware Request": "ASSET-MGMT"}
GROUP_MENTIONS = ["NET-OPS", "SEC-OPS", "IAM", "DBA"]
DEFAULT_APP = {
    "VPN": "VPN client", "Wireless": "Corporate Wi-Fi", "DNS/DHCP": "Corporate network",
    "Firewall": "Web proxy / firewall", "Network Drive": "File shares", "Oracle": "Oracle DB",
    "MS SQL Server": "SQL Server", "DB2": "DB2", "PostgreSQL": "PostgreSQL", "MySQL": "MySQL",
    "CPU": "Laptop", "Monitor": "Display", "Laptop": "Laptop", "Printer": "Print service",
    "Keyboard/Mouse": "Peripherals", "Email": "Outlook / Exchange Online", "Operating System": "Windows 11",
    "Installation": "Software Center", "Application Error": "Business application",
    "Collaboration Tools": "Microsoft 365", "Password Reset": "Identity (AD / Entra ID)",
    "Account Lockout": "Identity (AD / Entra ID)", "MFA": "Authenticator / Entra ID",
    "Access Request": "Identity (AD / Entra ID)", "Phishing/Malware": "Email security / EDR",
    "How-To": "Microsoft 365", "Software Request": "Software Center", "Hardware Request": "Asset management",
    "Antivirus": "Endpoint protection", "Internal Application": "Internal web apps",
}
APP_IS_NOT_APPLICATION = {"Network Drive", "Monitor", "CPU", "Hardware Request"}
DUR_MEDIAN_H = {"P1": 3, "P2": 8, "P3": 20, "P4": 36}
TIER_MULT = {"L1": 0.6, "L2": 1.5, "L3": 2.5}


def most_severe(*ps):
    ps = [p for p in ps if p]
    return min(ps, key=lambda p: SEV[p])


def fix_articles(s: str) -> str:
    s = re.sub(r"\b([Aa]) ([aeiouAEIOU])", lambda m: ("An " if m.group(1) == "A" else "an ") + m.group(2), s)
    return s


def cap(s: str) -> str:
    return s[:1].upper() + s[1:] if s else s


class Gen:
    def __init__(self, seed=SEED):
        self.r = random.Random(seed)
        self.seen = set()

    # ------------------------------------------------------------------ helpers
    def pick(self, xs):
        return self.r.choice(xs)

    def fill(self, tpl, ctx):
        out = tpl
        for k, v in ctx.items():
            out = out.replace("{" + k + "}", str(v))
        return cap(fix_articles(out))

    def when(self):
        span = (END - START).total_seconds()
        while True:
            t = START + timedelta(seconds=self.r.random() * span)
            weekday = t.weekday() < 5
            if (weekday and self.r.random() < 0.97) or (not weekday and self.r.random() < 0.25):
                break
        hour = int(min(21, max(6, self.r.gauss(12.5, 3.0))))
        return t.replace(hour=hour, minute=self.r.randrange(60), second=0)

    def choose_impact(self, sc):
        if sc.intent != "incident":
            return 3
        b = sc.impact_bias
        p_many = min(0.25, 0.07 * b ** 1.5)
        p_multi = min(0.40, 0.20 * b)
        x = self.r.random()
        return 1 if x < p_many else 2 if x < p_many + p_multi else 3

    def choose_urgency(self, sc):
        if sc.intent != "incident":
            return 2 if self.r.random() < 0.15 else 3
        x = self.r.random()
        return 1 if x < 0.18 else 2 if x < 0.53 else 3

    # ------------------------------------------------------------------ ticket
    def make(self, sc, fixed=None, dup=False):
        """Generate one ticket for scenario sc. `fixed` pins contextual choices (for duplicates)."""
        fixed = fixed or {}
        for _attempt in range(60):
            env = fixed.get("env") or (self.pick(sc.envs) if sc.category != "Database" else "production")
            loc = fixed.get("loc") or (self.pick(LOCS) if env != "remote" else "Home / remote")
            dept = fixed.get("dept") or self.pick(DEPTS)
            app = fixed.get("app") or (self.pick(sc.apps) if sc.apps else None)
            code = fixed["code"] if "code" in fixed else (
                self.pick(sc.codes) if sc.codes and self.r.random() < 0.8 else None)
            impact = fixed.get("impact") or self.choose_impact(sc)
            urgency = fixed.get("urgency") or self.choose_urgency(sc)
            n = {1: self.r.randint(10, 180), 2: self.r.randint(2, 9), 3: 1}[impact]
            ap = f"{self.pick('ABC')}{self.r.randint(1, 6)}-{self.r.randint(1, 24):02d}"
            ctx = {"app": app or "", "loc": loc, "dept": dept, "n": n, "ap": ap, "code": code or ""}

            sym_pool = [s for s in sc.symptoms if (code or "{code}" not in s) and (app or "{app}" not in s)
                        and (env != "remote" or "{loc}" not in s)]
            if fixed.get("avoid_symptom") and len(sym_pool) > 1 and self.r.random() < 0.5:
                sym_pool = [s for s in sym_pool if s != fixed["avoid_symptom"]] or sym_pool
            sym_tpl = self.pick(sym_pool)
            code_in_text = bool(code) and "{code}" in sym_tpl

            title_pool = [t for t in sc.titles if (code or "{code}" not in t) and (app or "{app}" not in t)
                          and (env != "remote" or "{loc}" not in t)]
            if fixed.get("avoid_title") and len(title_pool) > 1:
                title_pool = [t for t in title_pool if t != fixed["avoid_title"]] or title_pool
            title_tpl = self.pick(title_pool)
            title = self.fill(title_tpl, ctx)
            code_in_text = code_in_text or (bool(code) and "{code}" in title_tpl)

            signal = impact != 3 or urgency != 3
            if signal:
                mode = "medium" if self.r.random() < 0.55 else "long"
            else:
                x = self.r.random()
                mode = "short" if x < 0.30 else "medium" if x < 0.75 else "long"

            parts = []
            if mode == "long" and self.r.random() < 0.6:
                parts.append(self.pick(OPENERS))
            parts.append(self.fill(sym_tpl, ctx))
            if code and "{code}" not in sym_tpl and (dup or (mode != "short" and self.r.random() < 0.85)):
                parts.append(self.fill(self.pick(CODE_TPL), ctx))
                code_in_text = True
            if sc.intent == "incident":
                if mode != "short" and self.r.random() < (0.85 if mode == "long" else 0.55):
                    onset = self.pick(ONSET.get(sc.category, []) + ONSET["_"])
                    parts.append(self.pick(ONSET_TPL).format(onset=onset))
                tried = [] if sc.subcategory == "Phishing/Malware" else (TRIED.get(sc.category) or [])
                if tried and mode != "short" and self.r.random() < (0.8 if mode == "long" else 0.35):
                    parts.append(self.pick(tried))
            else:
                if mode != "short" and self.r.random() < (0.9 if mode == "long" else 0.5):
                    parts.append(self.fill(self.pick(REQUEST_CTX), ctx))
            if sc.intent == "incident" and mode != "short" and self.r.random() < 0.22:
                pool = [x for x in NOISE if not (env == "remote" and "office" in x)
                        and not (env != "remote" and "from home" in x)]
                parts.append(self.pick(pool))
            text_so_far = " ".join(parts)
            if (dup or (mode == "long" and self.r.random() < 0.4)) and loc not in text_so_far:
                parts.append(self.fill(self.pick(LOC_TPL["remote" if env == "remote" else "office"]), ctx))
            if impact != 3 or (mode == "long" and sc.intent == "incident" and self.r.random() < 0.4):
                pool = [p for p in IMPACT_TPL[impact] if env != "remote" or "{loc}" not in p]
                parts.append(self.fill(self.pick(pool), ctx))
            if dup and self.r.random() < 0.5:
                parts.append(self.pick(["A colleague may have already reported this.",
                                        "Not sure if someone else raised this already.",
                                        "Same problem as reported earlier by my teammate."]))
            if sc.intent == "incident":
                if urgency != 3 or (mode == "long" and self.r.random() < 0.3):
                    parts.append(self.fill(self.pick(URGENCY_TPL[urgency]), ctx))
            else:
                if urgency != 3 or (mode == "long" and self.r.random() < 0.4):
                    parts.append(self.fill(self.pick(REQUEST_URGENCY[urgency]), ctx))
            if mode == "long" and self.r.random() < 0.5:
                parts.append(self.pick(CLOSERS))
            desc = re.sub(r"\s+", " ", " ".join(p for p in parts if p)).strip()
            desc = re.sub(r"([.!?])(['\"])\.", r"\1\2", desc)
            key = desc.lower()
            if key in self.seen:
                continue
            self.seen.add(key)
            break
        else:
            raise RuntimeError(f"could not generate unique text for {sc.sid}")

        # priority
        if sc.intent == "incident":
            pri = most_severe(MATRIX[(impact, urgency)], sc.min_priority)
        else:
            pri = "P3" if urgency == 2 else "P4"
        return {
            "scenario": sc, "title": title, "description": desc, "env": env, "loc": loc, "dept": dept,
            "app": app, "code": code if code_in_text else None, "impact": impact, "urgency": urgency,
            "affected_users": n, "priority": pri, "ctx": ctx, "title_tpl": title_tpl, "sym_tpl": sym_tpl,
            "intent": sc.intent,
        }

    def make_vague(self, sc):
        for _ in range(40):
            line = self.pick(VAGUE[sc.subcategory]) + self.pick(VAGUE_SUFFIX)
            if line.lower() not in self.seen:
                break
        else:
            raise RuntimeError(f"vague collision {sc.subcategory}")
        self.seen.add(line.lower())
        env = self.pick(sc.envs) if sc.category != "Database" else "production"
        loc = self.pick(LOCS) if env != "remote" else "Home / remote"
        ctx = {"app": self.pick(sc.apps) if sc.apps else "", "loc": loc, "dept": self.pick(DEPTS), "n": 1,
               "ap": "A1-01", "code": ""}
        pri = "P3" if sc.intent == "incident" else "P4"
        title = self.pick(VAGUE[sc.subcategory]).rstrip(".")
        return {"scenario": sc, "title": title, "description": line, "env": env, "loc": loc, "dept": ctx["dept"],
                "app": ctx["app"] or None, "code": None, "impact": 3, "urgency": 3, "affected_users": 1,
                "priority": pri, "ctx": ctx, "title_tpl": title, "sym_tpl": line, "intent": sc.intent,
                "vague": True}

    def resolve(self, t):
        sc = t["scenario"]
        opts = []
        for res in sc.resolutions:
            tier, text = res.split("|", 1)
            w = 1.0
            if tier == "L1":
                w *= 2.4 if t["impact"] == 3 else 0.8
            else:
                w *= 2.0 if (t["impact"] == 1 or t["priority"] == "P1") else 1.0
            opts.append((w, tier, text))
        total = sum(o[0] for o in opts)
        x, acc = self.r.random() * total, 0
        for w, tier, text in opts:
            acc += w
            if x <= acc:
                break
        resolution = self.fill(text, t["ctx"])
        if sc.kb and self.r.random() < 0.45:
            resolution += f" Followed {sc.kb}."
        group = "SERVICE-DESK"
        if tier != "L1":
            group = next((g for g in GROUP_MENTIONS if g in text),
                         SPECIALIST_SUB.get(sc.subcategory, SPECIALIST[sc.category]))
        med = DUR_MEDIAN_H[t["priority"]] * TIER_MULT[tier] * (1.5 if t["intent"] != "incident" else 1.0)
        hours = max(0.17, math.exp(math.log(med) + self.r.gauss(0, 0.6)))
        return resolution, tier, group, hours


def build(articles_path: Path, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    g = Gen()

    # -------------------------------------------------------------- KEDB
    original = json.loads(articles_path.read_text())
    assert len(original) == 30
    keys = list(original[0].keys())
    for a in NEW_ARTICLES:
        assert list(a.keys()) == keys, a["kb_id"]
        assert list(a["resolution"].keys()) == list(original[0]["resolution"].keys())
    articles = original + NEW_ARTICLES
    kb_ids = {a["kb_id"] for a in articles}
    for a in articles:
        for rid in a["related_kb_ids"]:
            assert rid in kb_ids, (a["kb_id"], rid)
    (out / "articles.json").write_text(json.dumps(articles, indent=2, ensure_ascii=False) + "\n")

    # -------------------------------------------------------------- tickets
    by_sub = defaultdict(list)
    for sc in SCENARIOS:
        assert sc.kb is None or sc.kb in kb_ids, (sc.sid, sc.kb)
        by_sub[(sc.category, sc.subcategory)].append(sc)

    tickets = []
    base_n = PER_SUBCATEGORY - DUPLICATES_PER_SUBCATEGORY - VAGUE_PER_SUBCATEGORY
    for cat, subs in TAXONOMY.items():
        for sub in subs:
            scs = by_sub[(cat, sub)]
            wsum = sum(s.weight for s in scs)
            alloc = [max(1, round(base_n * s.weight / wsum)) for s in scs]
            while sum(alloc) > base_n:
                alloc[alloc.index(max(alloc))] -= 1
            while sum(alloc) < base_n:
                alloc[alloc.index(min(alloc))] += 1
            group = []
            for sc, k in zip(scs, alloc):
                for _ in range(k):
                    t = g.make(sc)
                    t["opened"] = g.when()
                    group.append(t)
            for _ in range(VAGUE_PER_SUBCATEGORY):
                t = g.make_vague(g.pick(scs))
                t["opened"] = g.when()
                group.append(t)
            # deliberate near-duplicates (same incident reported again, rephrased)
            parents = [t for t in group if t["intent"] == "incident" and not t.get("vague")] or \
                [t for t in group if not t.get("vague")]
            for p in g.r.sample(parents, DUPLICATES_PER_SUBCATEGORY):
                fixed = {"env": p["env"], "loc": p["loc"], "dept": p["dept"], "app": p["app"],
                         "code": p["code"], "impact": p["impact"], "urgency": p["urgency"],
                         "avoid_title": p["title_tpl"], "avoid_symptom": p["sym_tpl"]}
                c = g.make(p["scenario"], fixed=fixed, dup=True)
                c["opened"] = p["opened"] + timedelta(minutes=g.r.randint(20, 36 * 60))
                c["priority"] = p["priority"]
                c["dup_parent"] = p
                group.append(c)
            tickets.extend(group)

    # resolution, timings
    for t in tickets:
        if "dup_parent" in t:
            continue
        res, tier, grp, hours = g.resolve(t)
        t.update(resolution=res, tier=tier, group=grp, resolved=t["opened"] + timedelta(hours=hours))
    for t in tickets:
        if "dup_parent" in t:
            p = t["dup_parent"]
            t.update(tier="L1", group="SERVICE-DESK",
                     resolved=max(p["resolved"], t["opened"] + timedelta(minutes=g.r.randint(10, 90))))

    # PII injection (~2%), for testing the privacy step
    for t in g.r.sample(tickets, 30):
        first, last = g.pick(FIRST), g.pick(LAST)
        extra = g.pick([
            f"You can reach me at {first.lower()}.{last.lower()}@example.com.",
            f"Please call me on +91 90000 {g.r.randint(10000, 99999)}.",
            f"My employee ID is EMP{g.r.randint(100000, 999999)} and my email is {first.lower()}.{last.lower()}@example.com.",
            f"Contact {first} {last} on +91 90000 {g.r.randint(10000, 99999)} if I'm unavailable.",
        ])
        t["description"] += " " + extra
        t["pii"] = True

    # IDs in chronological order
    tickets.sort(key=lambda t: t["opened"])
    for i, t in enumerate(tickets, 1):
        t["id"] = f"INC{i:04d}"
    for t in tickets:
        if "dup_parent" in t:
            t["duplicate_of"] = t["dup_parent"]["id"]
            t["resolution"] = (f"Duplicate of {t['duplicate_of']}. Linked to the parent incident and closed "
                               f"when the parent was resolved.")

    # stratified split (70/15/15 by subcategory); duplicates follow their parent
    split_of = {}
    for (cat, sub) in by_sub:
        ids = [t["id"] for t in tickets if t["scenario"].category == cat and t["scenario"].subcategory == sub
               and "dup_parent" not in t]
        g.r.shuffle(ids)
        n = len(ids)
        for j, tid in enumerate(ids):
            split_of[tid] = "train" if j < round(n * 0.70) else "val" if j < round(n * 0.85) else "test"
    for t in tickets:
        t["split"] = split_of[t["duplicate_of"]] if "dup_parent" in t else split_of[t["id"]]

    # -------------------------------------------------------------- records
    records = []
    for t in tickets:
        sc = t["scenario"]
        app = t["app"]
        application = (app[4:] if app and app.startswith("the ") else app) \
            if app and sc.subcategory not in APP_IS_NOT_APPLICATION else DEFAULT_APP[sc.subcategory]
        status = "resolved" if t["resolved"] > datetime(2026, 10, 28) else "closed"
        hours = round((t["resolved"] - t["opened"]).total_seconds() / 3600, 2)
        records.append({
            "id": t["id"], "title": t["title"], "description": t["description"],
            "category": sc.category, "subcategory": sc.subcategory, "priority": t["priority"],
            "status": status, "resolution": t["resolution"],
            "metadata": {
                "source": "synthetic_team", "dataset": "it_tickets_synth_v1", "language": "en",
                "generator": "gen/build_datasets.py (seed 42)", "resolution_origin": "synthetic_generated",
                "priority_level": LEVEL[t["priority"]], "impact": t["impact"], "urgency": t["urgency"],
                "intent": t["intent"],
                "opened_at": t["opened"].isoformat(timespec="minutes"),
                "resolved_at": t["resolved"].isoformat(timespec="minutes"),
                "resolution_hours": hours, "resolved_by_tier": t["tier"], "escalated": t["tier"] != "L1",
                "assignment_group": t["group"], "application": application, "environment": t["env"],
                "location": t["loc"], "affected_users": t["affected_users"], "error_code": t["code"],
                "related_kb_id": sc.kb, "duplicate_of": t.get("duplicate_of"),
                "contains_pii": bool(t.get("pii")), "text_quality": "vague" if t.get("vague") else "normal",
                "split": t["split"], "scenario_id": sc.sid,
            },
        })
    (out / "tickets.json").write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n")

    # -------------------------------------------------------------- taxonomy map
    kb_by_id = {a["kb_id"]: a for a in articles}
    lines = ["# Ticket subcategory -> KEDB articles. Generated by gen/build_datasets.py from the scenario links.",
             "# primary: articles linked to tickets of this subcategory (most frequent first)",
             "# secondary: related_kb_ids of the primary articles (soft boost only)", "version: 2", "map:"]
    cov_rows = []
    for cat, subs in TAXONOMY.items():
        lines.append(f"  \"{cat}\":")
        for sub in subs:
            cnt = Counter(r["metadata"]["related_kb_id"] for r in records
                          if r["category"] == cat and r["subcategory"] == sub and r["metadata"]["related_kb_id"])
            primary = [k for k, _ in cnt.most_common()]
            secondary = sorted({rid for k in primary for rid in kb_by_id[k]["related_kb_ids"]} - set(primary))
            no_kb = sum(1 for r in records if r["category"] == cat and r["subcategory"] == sub
                        and not r["metadata"]["related_kb_id"])
            lines.append(f"    \"{sub}\": {{primary: [{', '.join(primary)}], secondary: [{', '.join(secondary)}]}}")
            cov_rows.append((cat, sub, primary, secondary, no_kb))
    (out / "taxonomy_map.yaml").write_text("\n".join(lines) + "\n")

    write_xlsx(out / "Dataset_ticket_5.xlsx", records, cov_rows, kb_by_id)
    return articles, records


def write_xlsx(path, records, cov_rows, kb_by_id):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    F = "Arial"
    hdr_font = Font(name=F, bold=True, color="FFFFFF", size=10)
    hdr_fill = PatternFill("solid", start_color="1F3864")
    body = Font(name=F, size=10)
    bold = Font(name=F, size=10, bold=True)
    title_font = Font(name=F, size=14, bold=True)
    note = Font(name=F, size=9, italic=True, color="595959")
    thin = Side(style="thin", color="D9D9D9")
    border = Border(bottom=thin)

    wb = Workbook()
    ws = wb.active
    ws.title = "Tickets"
    cols = [("Ticket ID", 11), ("Title", 42), ("Description", 80), ("Category", 17), ("Subcategory", 19),
            ("Priority", 9), ("Priority Level", 12), ("Impact", 8), ("Urgency", 9), ("Intent", 11),
            ("Status", 10), ("Resolution", 70), ("Resolved By Tier", 10), ("Escalated", 10),
            ("Assignment Group", 16), ("Application", 26), ("Environment", 12), ("Location", 28),
            ("Affected Users", 10), ("Error Code", 34), ("Related KB ID", 12), ("Opened At", 17),
            ("Resolved At", 17), ("Resolution Hours", 11), ("Duplicate Of", 12), ("Contains PII", 10),
            ("Text Quality", 10), ("Split", 8), ("Scenario ID", 20), ("Source", 15)]
    for j, (name, w) in enumerate(cols, 1):
        c = ws.cell(row=1, column=j, value=name)
        c.font, c.fill = hdr_font, hdr_fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[1].height = 30
    for i, r in enumerate(records, 2):
        m = r["metadata"]
        row = [r["id"], r["title"], r["description"], r["category"], r["subcategory"], r["priority"],
               m["priority_level"], m["impact"], m["urgency"], m["intent"], r["status"], r["resolution"],
               m["resolved_by_tier"], "Yes" if m["escalated"] else "No", m["assignment_group"], m["application"],
               m["environment"], m["location"], m["affected_users"], m["error_code"] or "",
               m["related_kb_id"] or "", datetime.fromisoformat(m["opened_at"]),
               datetime.fromisoformat(m["resolved_at"]), f"=ROUND((W{i}-V{i})*24,2)",
               m["duplicate_of"] or "", "Yes" if m["contains_pii"] else "No", m["text_quality"], m["split"], m["scenario_id"],
               m["source"]]
        for j, v in enumerate(row, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.font = body
            c.alignment = Alignment(vertical="top", wrap_text=j in (2, 3, 12))
        ws.cell(row=i, column=22).number_format = "yyyy-mm-dd hh:mm"
        ws.cell(row=i, column=23).number_format = "yyyy-mm-dd hh:mm"
        ws.cell(row=i, column=24).number_format = "0.00"
    last = len(records) + 1
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{last}"

    # ---------------------------------------------------------------- Summary (formulas)
    s = wb.create_sheet("Summary")
    s.column_dimensions["A"].width = 22
    s.column_dimensions["B"].width = 24
    for col in "CDEFG":
        s.column_dimensions[col].width = 14
    s["A1"] = "Synthetic IT ticket dataset: summary"
    s["A1"].font = title_font
    s["A2"] = ("All figures are live formulas over the Tickets sheet. Data is synthetic (source = synthetic_team), "
               "generated by gen/build_datasets.py with seed 42.")
    s["A2"].font = note
    rng = lambda col: f"Tickets!${col}$2:${col}${last}"  # noqa: E731

    def header(row, labels):
        for j, lab in enumerate(labels, 1):
            c = s.cell(row=row, column=j, value=lab)
            c.font, c.fill = hdr_font, hdr_fill
            c.alignment = Alignment(horizontal="center")

    r0 = 4
    s.cell(row=r0, column=1, value="By category").font = bold
    header(r0 + 1, ["Category", "", "Tickets", "Escalated", "Escalation %", "Avg res. hours", "Duplicates"])
    cats = list(TAXONOMY)
    for k, cat in enumerate(cats):
        rr = r0 + 2 + k
        s.cell(row=rr, column=1, value=cat)
        s.cell(row=rr, column=3, value=f"=COUNTIFS({rng('D')},A{rr})")
        s.cell(row=rr, column=4, value=f'=COUNTIFS({rng("D")},A{rr},{rng("N")},"Yes")')
        s.cell(row=rr, column=5, value=f"=IF(C{rr}=0,0,D{rr}/C{rr})").number_format = "0.0%"
        s.cell(row=rr, column=6, value=f"=AVERAGEIFS({rng('X')},{rng('D')},A{rr})").number_format = "0.0"
        s.cell(row=rr, column=7, value=f'=COUNTIFS({rng("D")},A{rr},{rng("Y")},"<>")')
    tot = r0 + 2 + len(cats)
    s.cell(row=tot, column=1, value="Total").font = bold
    for col in "CDG":
        s[f"{col}{tot}"] = f"=SUM({col}{r0 + 2}:{col}{tot - 1})"
        s[f"{col}{tot}"].font = bold
    s[f"E{tot}"] = f"=IF(C{tot}=0,0,D{tot}/C{tot})"
    s[f"E{tot}"].number_format = "0.0%"
    s[f"F{tot}"] = f"=AVERAGE({rng('X')})"
    s[f"F{tot}"].number_format = "0.0"

    r1 = tot + 3
    s.cell(row=r1, column=1, value="By priority").font = bold
    header(r1 + 1, ["Priority", "Level", "Tickets", "Share", "Avg res. hours", "", ""])
    for k, (p, lev) in enumerate(LEVEL.items()):
        rr = r1 + 2 + k
        s.cell(row=rr, column=1, value=p)
        s.cell(row=rr, column=2, value=lev)
        s.cell(row=rr, column=3, value=f"=COUNTIFS({rng('F')},A{rr})")
        s.cell(row=rr, column=4, value=f"=IF($C${tot}=0,0,C{rr}/$C${tot})").number_format = "0.0%"
        s.cell(row=rr, column=5, value=f'=IFERROR(AVERAGEIFS({rng("X")},{rng("F")},A{rr}),0)').number_format = "0.0"

    r2 = r1 + 8
    s.cell(row=r2, column=1, value="By subcategory").font = bold
    header(r2 + 1, ["Category", "Subcategory", "Tickets", "With error code", "Linked to KB", "Escalated", "PII rows"])
    rr = r2 + 2
    for cat, subs in TAXONOMY.items():
        for sub in subs:
            s.cell(row=rr, column=1, value=cat)
            s.cell(row=rr, column=2, value=sub)
            s.cell(row=rr, column=3, value=f"=COUNTIFS({rng('D')},A{rr},{rng('E')},B{rr})")
            s.cell(row=rr, column=4, value=f'=COUNTIFS({rng("D")},A{rr},{rng("E")},B{rr},{rng("T")},"<>")')
            s.cell(row=rr, column=5, value=f'=COUNTIFS({rng("D")},A{rr},{rng("E")},B{rr},{rng("U")},"<>")')
            s.cell(row=rr, column=6, value=f'=COUNTIFS({rng("D")},A{rr},{rng("E")},B{rr},{rng("N")},"Yes")')
            s.cell(row=rr, column=7, value=f'=COUNTIFS({rng("D")},A{rr},{rng("E")},B{rr},{rng("Z")},"Yes")')
            rr += 1
    for row in s.iter_rows(min_row=4, max_row=rr):
        for c in row:
            if c.font is None or c.font.name != F:
                c.font = Font(name=F, size=10, bold=c.font.bold if c.font else False,
                              color=c.font.color if c.font else None)

    # ---------------------------------------------------------------- KB Coverage
    k = wb.create_sheet("KB Coverage")
    for col, w in zip("ABCDEF", (19, 21, 34, 30, 14, 60)):
        k.column_dimensions[col].width = w
    k["A1"] = "Ticket subcategory -> KEDB coverage (same content as taxonomy_map.yaml)"
    k["A1"].font = title_font
    hdrs = ["Category", "Subcategory", "Primary KB IDs", "Secondary KB IDs", "Tickets without KB", "Primary KB titles"]
    for j, h in enumerate(hdrs, 1):
        c = k.cell(row=3, column=j, value=h)
        c.font, c.fill = hdr_font, hdr_fill
    for i, (cat, sub, prim, sec, no_kb) in enumerate(cov_rows, 4):
        vals = [cat, sub, ", ".join(prim), ", ".join(sec), no_kb, " | ".join(kb_by_id[x]["title"] for x in prim)]
        for j, v in enumerate(vals, 1):
            c = k.cell(row=i, column=j, value=v)
            c.font = body
            c.alignment = Alignment(vertical="top", wrap_text=j == 6)

    # ---------------------------------------------------------------- Data Dictionary
    d = wb.create_sheet("Data Dictionary")
    d.column_dimensions["A"].width = 20
    d.column_dimensions["B"].width = 26
    d.column_dimensions["C"].width = 100
    d["A1"] = "Data dictionary"
    d["A1"].font = title_font
    d["A2"] = ("Synthetic data notice: every row is generated (source = synthetic_team). Resolutions, timestamps, "
               "groups and locations are realistic but not real incidents. Labels follow the rules below.")
    d["A2"].font = note
    dd = [
        ("Ticket ID", "tickets.json: id", "INC0001..INC1500, numbered in order of Opened At."),
        ("Title / Description", "title / description", "Reporter-voice text. ~30% of low-signal tickets are one sentence; others add error code, onset, steps tried, impact and urgency."),
        ("Category / Subcategory", "category / subcategory", "6 categories x 5 subcategories x 50 tickets (taxonomy below). Gold label for classification."),
        ("Priority", "priority", "Incidents: impact x urgency matrix (I1U1=P1; I1U2, I1U3, I2U1, I2U2, I3U1=P2; others P3), floored at P3, raised to the scenario minimum where one applies (e.g. ransomware P1). Requests/how-to: P4, or P3 when the reporter gives a near deadline. Every non-default impact/urgency is stated in the description, so the label can be inferred from the text."),
        ("Priority Level", "metadata.priority_level", "Contract wording: P1 Critical, P2 High, P3 Medium, P4 Low."),
        ("Impact / Urgency", "metadata.impact / urgency", "1 = high, 3 = low. Impact 1 = 10+ users, 2 = 2-9 users / team, 3 = single user."),
        ("Intent", "metadata.intent", "incident, request or how_to."),
        ("Status", "status", "closed, or resolved if resolved after 2026-10-28."),
        ("Resolution", "resolution", "What fixed it (synthetic_generated). Duplicates say 'Duplicate of INCxxxx'. Some cite the KB article followed."),
        ("Resolved By Tier / Escalated", "metadata.resolved_by_tier / escalated", "L1 = service desk; L2/L3 = specialist team (Escalated = Yes)."),
        ("Assignment Group", "metadata.assignment_group", "Resolving group: SERVICE-DESK for L1, otherwise NET-OPS, DBA, EUC-HW, EUC-SW, IAM, SEC-OPS, APP-SUPPORT or ASSET-MGMT."),
        ("Application / Environment / Location", "metadata.application / environment / location", "Filter fields for FR-07. Environment: office, remote or production (all Database tickets)."),
        ("Affected Users", "metadata.affected_users", "Number implied by the description (1, 2-9 or 10-180)."),
        ("Error Code", "metadata.error_code", "Error code/message quoted in the text (only when it actually appears in the title or description). Most map to a KEDB common_error_codes entry."),
        ("Related KB ID", "metadata.related_kb_id", "KEDB article that addresses the scenario. Blank for deliberate KB-gap scenarios (tests fallback/escalation)."),
        ("Opened At / Resolved At", "metadata.opened_at / resolved_at", "2026-05-01 to 2026-10-31, business-hours weighted. Duration is log-normal by priority and tier."),
        ("Resolution Hours", "metadata.resolution_hours", "Formula: (Resolved At - Opened At) x 24."),
        ("Duplicate Of", "metadata.duplicate_of", "3 deliberate near-duplicates per subcategory (90 total): same incident re-reported with different wording within 36 h. Gold pairs for duplicate detection."),
        ("Contains PII", "metadata.contains_pii", "30 rows include fake emails (example.com), phone numbers or employee IDs to test the privacy/redaction step. Redact before indexing."),
        ("Text Quality", "metadata.text_quality", "vague = 3 deliberately under-specified one-liners per subcategory (90 total, e.g. 'Can't log in.'). Labelled by the resolving analyst; expected to get low confidence / a clarifying question."),
        ("Split", "metadata.split", "Suggested stratified split by subcategory: train 70% / val 15% / test 15%. Duplicates follow their parent."),
        ("Scenario ID", "metadata.scenario_id", "Generator scenario. Useful for error analysis; do not use as a model feature."),
    ]
    for j, h in enumerate(["Column", "tickets.json field", "Meaning / rule"], 1):
        c = d.cell(row=4, column=j, value=h)
        c.font, c.fill = hdr_font, hdr_fill
    for i, (a_, b_, c_) in enumerate(dd, 5):
        for j, v in enumerate((a_, b_, c_), 1):
            c = d.cell(row=i, column=j, value=v)
            c.font = bold if j == 1 else body
            c.alignment = Alignment(vertical="top", wrap_text=True)
    r = 5 + len(dd) + 2
    d.cell(row=r, column=1, value="Taxonomy").font = bold
    for i, (cat, subs) in enumerate(TAXONOMY.items(), r + 1):
        d.cell(row=i, column=1, value=cat).font = body
        d.cell(row=i, column=3, value=", ".join(subs)).font = body

    wb.save(path)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--articles", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    arts, recs = build(a.articles, a.out)
    print(f"articles: {len(arts)}  tickets: {len(recs)}")
